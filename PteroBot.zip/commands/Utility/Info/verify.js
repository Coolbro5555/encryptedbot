const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const client = require('../../..');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const verifyrole = require('../../../utils.json').verifyrole

module.exports = {
    name: "verify",
    description: "verify command",
    aliases: ['r', 'reaction'],

    run: async (client, message, args) => {

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`Verifieer jouw account hier, klik op de onderstaande button om de <@&${verifyrole}> role te ontvangen`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()

        const nv = new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId('Verify')
                .setStyle('SECONDARY')
                .setLabel('Verify')
                .setEmoji('👔')
        )

        message.channel.send({ embeds: [embed], components: [nv] })
    }
}

// © Bot created by Sides Hosting & Dev