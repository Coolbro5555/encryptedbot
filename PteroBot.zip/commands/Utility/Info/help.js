const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const client = require('../../..');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {

    name: "help",
    description: "help cmd",
    category: "general",
    run: async (client, message, args) => {

        const { commands } = message.client;
        const embed = new MessageEmbed()
            .setTitle(`${client.user.username}'s commands`)
            .setDescription(commands.map(c => `**\`${prefix}${c.name}\`**: ${c.description ? c.description : '*Geen beschrijving gegeven*'}`).join('\n')) // Mapping the commands
            .setTimestamp()
            .setThumbnail(gif)
            .setColor(color)
            .setFooter({ text: `${footer}` })

        return message.channel.send({ embeds: [embed] })
    }
}

// © Bot created by Sides Hosting & Dev