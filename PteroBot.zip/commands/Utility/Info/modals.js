const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu,
    Modal,
    TextInputComponent
} = require('discord.js');
const client = require('../../..');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const verifyrole = require('../../../utils.json').verifyrole

module.exports = {
    name: "modal",
    description: "modals voor jouw gegevens etc",
    aliases: ['m', 'modals'],

    run: async (client, message, args) => {

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Je hebt geen permisie om dit command uit te voeren, je hebt \`BAN_MEMBERS\` nodig`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has('BAN_MEMBERS')) return message.channel.send({ embeds: [embed] })

        return await message.reply({
            embeds: [
                new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`Druk op de knop onder dit bericht, hiervoor zou jij een een form moeten invullen.`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

            ],
			components: [new MessageActionRow()
                .addComponents(new MessageButton()
                    .setLabel('Claim jouw naam')
                    .setStyle('SECONDARY')
                    .setEmoji('🙋‍♂️')
                    .setCustomId('button')
                    .setDisabled(false))
            ],
            ephemeral: true
        });

    }
}

// © Bot created by Sides Hosting & Dev