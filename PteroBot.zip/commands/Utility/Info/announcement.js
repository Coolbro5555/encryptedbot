const { MessageEmbed, Message, MessageActionRow, MessageSelectMenu } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: "announcement",
    aliases: ['announce'],
    description: "maak een announcement in de server",

    run: async (client, message, args) => {

        message.delete()

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Je hebt geen permissie voor dit command, je hebt \`BAN_MEMBERS\` nodig voor dit command`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has('BAN_MEMBERS')) return message.channel.send({ embeds: [embed] })

        var splitser = '|'
        args = args.join(" ").split(splitser)

        if (args[0] == null) {

            var errorEmbed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`🚫 Geef een announcement titel op, doe dat zo: \`!announcement titel | description | kleurcode (zoals #fffff)\``)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            return message.channel.send({ embeds: [errorEmbed] })

        }

        if (args[1] == null) {

            var errorEmbed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`🚫 Geef een announcement beschrijving op, doe dat zo: \`!announcement titel | description | kleurcode (zoals #fffff)\``)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            return message.channel.send({ embeds: [errorEmbed] })

        }

        if (args[2] == null) {

            var errorEmbed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`🚫 Geef een announcement **kleurcode** op, doe dat zo: \`!announcement titel | description | kleurcode (zoals #fffff)\``)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            return message.channel.send({ embeds: [errorEmbed] })

        }

        var options = {

            title: args[0] || 'Geen titel meegegeven',
            bericht: args[1] || 'Geen description meegegeven',
            kleur: args[2] || "#ffffff",

        }

        const embed1 = new MessageEmbed()
            .setTitle(`${options.title}`)
            .setDescription(`${options.bericht}`)
            .setColor(`${options.kleur}`)

        message.channel.send({ embeds: [embed1] })



    }
}  

// © Bot created by Sides Hosting & Dev