const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const ticketpanelchannel = require('../../../utils.json').ticketpanelchannel
const ticket1 = require('../../../utils.json').ticket1
const ticket2 = require('../../../utils.json').ticket2
const ticket3 = require('../../../utils.json').ticket3
const ticket4 = require('../../../utils.json').ticket4
const ticket5 = require('../../../utils.json').ticket5
const ticket6 = require('../../../utils.json').ticket6
const ticketstaffrole = require('../../../utils.json').ticketstaffrole

module.exports = {
    name: "ticket",
    description: "ticket panel command",
    aliases: ['t'],

    run: async (client, message, args) => {

        message.delete()

        const embed12 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Je moet in de files het \`id\` van de ticketstaffrole toevoegen`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (ticketstaffrole == "") return message.channel.send({ embeds: [embed12] })
        
        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Je hebt geen permissie om dit command uit te voeren! Als je een ticket wilt aanmaken, doe dat dan in <#${ticketpanelchannel}>`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const embed = new MessageEmbed()
            .setColor(color)
            .setDescription(`Hoi en welkom bij de officiële \`${message.guild.name}\` tickets! Heb jij support nodig of heb jij enkele vragen? Klik dan op een van de keuzes hieronder!\n\n*Beschikbare categorieën:*\n\`\`\`・ ${ticket1}\n・ ${ticket2}\n・ ${ticket3}\n・ ${ticket4}\n・ ${ticket5}\n・ ${ticket6}\`\`\``)
            .setAuthor({ name: `${message.guild.name} Tickets`, iconURL: `${gif}` })
            .setImage(gif)
            .setFooter({ text: `${footer}` })
            .setTimestamp()

        const nv = new MessageActionRow().addComponents(
            new MessageSelectMenu()
                .setCustomId('ja')
                .setPlaceholder('❌ | Nog niets geselecteerd')
                .addOptions({
                    emoji: '🙋‍♂️',
                    label: `${ticket1}`,
                    description: `Maak hier jouw ${ticket1} ticket`,
                    value: "ticket1"
                },
                    {
                        emoji: '🔒',
                        label: `${ticket2}`,
                        description: `Maak hier jouw ${ticket2} ticket`,
                        value: "ticket2"
                    },
                    {
                        emoji: '👨‍💻',
                        label: `${ticket3}`,
                        description: `Maak hier jouw ${ticket3} ticket`,
                        value: "ticket3"
                    },
                    {
                        emoji: '👨‍💻',
                        label: `${ticket4}`,
                        description: `Maak hier jouw ${ticket4} ticket`,
                        value: "ticket4"
                    },
                    {
                        emoji: '👨‍💻',
                        label: `${ticket5}`,
                        description: `Maak hier jouw ${ticket5} ticket`,
                        value: "ticket5"
                    },
                    {
                        emoji: '👨‍💻',
                        label: `${ticket6}`,
                        description: `Maak hier jouw ${ticket6} ticket`,
                        value: "ticket6"
                    },
                    {
                        emoji: '🔗',
                        label: `Reset`,
                        description: `Reset jouw keuze`,
                        value: "Reset"
                    }
                )
        )

        message.channel.send({ components: [nv], embeds: [embed] })

        if (!ticket1 == "") {

            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket1} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket1} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }

        if (!ticket2 == "") {
            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket2} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket2} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }

        if (!ticket3 == "") {
            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket3} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket3} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }

        if (!ticket4 == "") {
            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket4} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket4} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }

        if (!ticket5 == "") {
            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket5} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket5} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }

        if (!ticket6 == "") {
            const channel1 = message.guild.channels.cache.find(channel => channel.name === `${ticket6} - Ticket`)

            if (channel1) {

            } else {
                message.guild.channels.create(`${ticket6} - Ticket`, {
                    type: 'GUILD_CATEGORY',
                    permissionOverwrites: [
                        {
                            id: message.guild.roles.everyone,
                            deny: ['VIEW_CHANNEL']
                        },
                        {
                            id: ticketstaffrole,
                            allow: ['VIEW_CHANNEL']
                        }
                    ]
                })
                    .catch(console.error);
            }
        }
    }
}

// © Bot created by Sides Hosting & Dev