const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const ticketpanelchannel = require('../../../utils.json').ticketpanelchannel

module.exports = {
    name: "rename",
    description: "geeft een kanaal een andere naam",
    aliases: ['r'],

    run: async (client, message, args) => {

        message.delete()

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Je hebt geen permissie voor dit command, je hebt \`BAN_MEMBERS\` nodig voor dit command`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has('BAN_MEMBERS')) return message.channel.send({ embeds: [embed] })

        const name = args.join(" ")

        if (!name) {

            const embed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`🚫 Geef de naam op naar wat je de channel wilt renamen, doe dat zo: \`${prefix}rename channelnaam\``)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            return message.channel.send({ embeds: [embed] })
        }

        message.channel.setName(name)
        await message.channel.send({embeds: [new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`De kanaalnaam is succesvol aangapast naar \`${name}\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()]}).then((embed) => {
                setTimeout(() => {
                    embed.delete()
                }, 10000);
            })

    }
}

// © Bot created by Sides Hosting & Dev