const Discord = require('discord.js'),
    { MessageEmbed } = Discord,
    parsec = require('parsec'),
    messages = require('../../../utils/message');
const color = require('../../../utils.json').color

module.exports = {

    name: "giveaway",
    aliases: ['g'],
    description: "een giveway start command",
    category: "general",

    run: async (client, message, args) => {

        const collector = message.channel.createMessageCollector({
            filter: (m) => m.author.id === message.author.id,
            time: 60000,
        });

        function waitingEmbed(title, desc) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setAuthor({
                            name: `${message.author.tag} | Giveaway Setup`,
                            iconURL: message.member.displayAvatarURL()
                        })
                        .setTitle('Giveaway ' + title)
                        .setDescription(desc + ' en reageer binnen 60 seconden')
                        .setFooter({
                            text: "Typ 'cancel' om de giveaway te stoppen",
                            iconURL: client.user.displayAvatarURL()
                        })
                        .setTimestamp()
                        .setColor(color)
                ],
            });
        }

        let winnerCount, channel, duration, prize, cancelled;

        await waitingEmbed('Prijs', 'Geef een giveawayprijs op');

        collector.on('collect', async (m) => {
            if (cancelled) return;

            async function failed(options, ...cancel) {
                if (typeof cancel[0] === 'boolean')
                    (cancelled = true) && (await m.reply(options));
                else {
                    await m.reply(
                        options instanceof MessageEmbed ? { embeds: [options] } : options
                    );
                    return await waitingEmbed(...cancel);
                }
            }

            if (m.content === 'cancel') {
                collector.stop()
                return await failed('De giveaway is geannuleerd', true)
            }

            switch (true) {
                case !prize: {
                    if (m.content.length > 256)
                        return await failed(
                            'De prijs mag niet meer dan 256 tekens bevatten',
                            'Prijs',
                            'Stuur aub een giveaway prijs'
                        );
                    else {
                        prize = m.content;
                        await waitingEmbed('Channel', 'Geef een giveawaykanaal op');
                    }

                    break;
                }

                case !channel: {
                    if (!(_channel = m.mentions.channels.first() || m.guild.channels.cache.get(m.content)))
                        return await failed(
                            'Stuur aub een valide channel/channelID',
                            'Channel',
                            'Stuur een giveawayChannel'
                        );
                    else if (!_channel.isText())
                        return await failed(
                            'Het channel moet een tekstkanaal zijn',
                            'Channel',
                            'Stuur een giveawayChannel'
                        );
                    else {
                        channel = _channel;
                        await waitingEmbed(
                            'Winnaar aantal',
                            'Geef het winnaar aantaal op'
                        );
                    }

                    break;
                }

                case !winnerCount: {
                    if (!(_w = parseInt(m.content)))
                        return await failed(
                            'Het nummer van het aantal winnaars moet een getal zijn',
                            'Winnaar aantal',
                            'Geef een winnaar aantal op'
                        );
                    if (_w < 1)
                        return await failed(
                            'Het winnaar aantal moet meer zijn dan 1',
                            'Winnaar aantal',
                            'Geef een winnaar aantal op'
                        );
                    else if (_w > 15)
                        return await failed(
                            'Het winnaar aantal moet minder zijn dan 15',
                            'Winnaar aantal',
                            'Geef een winnaar aantal op'
                        );
                    else {
                        winnerCount = _w;
                        await waitingEmbed('Tijd', 'Geef de lengte van de giveaway aan');
                    }

                    break;
                }

                case !duration: {
                    if (!(_d = parsec(m.content).duration))
                        return await failed(
                            'Geef een valide tijd op',
                            'Tijd',
                            'Geef de tijdsduur op van de giveaway'
                        );
                    if (_d > parsec('21d').duration)
                        return await failed(
                            'Duration must be less than 21 days!',
                            'Tijd',
                            'Geef de tijdsduur op van de giveaway'
                        );
                    else {
                        duration = _d;
                    }

                    return client.giveawaysManager.start(channel, {
                        prize,
                        duration,
                        winnerCount,
                        messages,
                        hostedBy: message.author,
                    });
                }
            }
        });



    }
}

// © Bot created by Sides Hosting & Dev