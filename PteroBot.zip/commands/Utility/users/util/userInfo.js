const { MessageEmbed, Message } = require('discord.js')
const moment = require('moment')
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix

module.exports = {
    name: "userinfo",
    description: "geeft informatie over een user in de server",
    aliases: ['whois', 'wi', 'u', 'u-i'],

    run: async (client, message, args) => {

        const Target = message.mentions.users.first() || message.author;
        const Member = message.guild.members.cache.get(Target.id)

        const response = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .addField("UserID", `${Target.id}`)
            .addField("Roles", `${Member.roles.cache.map(r => r).join(" ").replace("@everyone", " ")}`)
            .addField("Server Member Since", `${moment(Member.joinedAt).format('MMMM Do YYYY, h:mm:ss')}\n**-** ${moment(Member.joinedAt).startOf('minutes').fromNow()}`)
            .addField("Joined Discord", `${moment(Target.createdAt).format('MMMM Do YYYY, h:mm:ss')}\n**-** ${moment(Target.createdAt).startOf('minutes').fromNow()}`)
            .setAuthor({ name: `${Target.username} Userinfo`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()

        message.reply({ embeds: [response] })


    }
}

// © Bot created by Sides Hosting & Dev