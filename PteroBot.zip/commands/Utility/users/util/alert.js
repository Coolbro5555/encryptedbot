const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix
const ticketstaffrole = require('../../../../utils.json').ticketstaffrole

module.exports = {
    name: "alert",
    description: "geef staff een ping",
    aliases: ['staff'],

    run: async (client, message, args) => {
        message.delete()
        await channel.send({ content: `<@&${ticketstaffrole}> kunnen jullie z.s.m. op de ticket reageren.`})
    }
}