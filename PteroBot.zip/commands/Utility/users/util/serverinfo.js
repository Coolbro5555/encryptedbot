const { Message, Client, MessageEmbed, MessageActionRow, MessageSelectMenu } = require("discord.js");
const ticketpanelchannel = require('../../../../utils.json').ticketpanelchannel
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix

module.exports = {
    name: "serverinfo",
    description: "geeft alle info van de server",
    aliases: ['server', 'sinfo', 'server-info', 's-info'],
   
    run: async (client, message, args) => {

        if (!message.member.permissions.has("KICK_MEMBERS")) return;

        const guild = message.guild;
        const user = message.author;

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setAuthor({ name: `${message.guild.name} - Serverinfo`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
            .addFields(
                { name: `\u200b`, value: `\u200b` },
                { name: '**ServerNaam**', value: `\`\`\`${guild.name}\`\`\`` },
                { name: '**Memberount**', value: `\`\`\`${guild.memberCount}\`\`\``, inline: true },
                { name: '**Server Created**', value: `\`\`\`${guild.createdAt.toDateString()}\`\`\``, inline: true },
                { name: '**Roles**', value: `\`\`\`${guild.roles.cache.size}\`\`\``, inline: true },
                { name: '**Text Channels**', value: `\`\`\`${guild.channels.cache.filter(channel => channel.type === "GUILD_TEXT").size}\`\`\``, inline: true },
                { name: '**Voice Channels**', value: `\`\`\`${guild.channels.cache.filter(channel => channel.type === "GUILD_VOICE").size}\`\`\``, inline: true },
            )
        return message.channel.send({ embeds: [embed] })


    },
};

// © Bot created by Sides Hosting & Dev