const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix
const discordsuggestionchannel = require('../../../../utils.json').discordsuggestionchannel

module.exports = {
    name: "discordsuggest",
    description: "doe een suggestie in de server",
    aliases: [],

    run: async (client, message, args) => {

        message.delete()

        const suggestionsButtonRow = new MessageActionRow().addComponents(

            new MessageButton()
                .setCustomId('suggestion_accept')
                .setLabel('Accepteren')
                .setStyle('SUCCESS'),

            new MessageButton()
                .setCustomId('suggestion_deny')
                .setLabel('Afwijzen')
                .setStyle('DANGER')

        );

        if (args[0]) {

            let suggestionEmbed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setAuthor({ name: `${message.author.username}'s discord suggestie`, iconURL: `${gif}` })
                .setDescription(`\`\`\`${args.join(" ")}\`\`\``)

            try {
                const embed1 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`🚫 Het suggestie kanaal bestaat niet`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

                let channel = message.guild.channels.cache.get(kledingsuggestionchannel)
                if (!channel) return message.channel.send({ embeds: [embed1] })

                let suggestionMessage = await channel.send({
                    embeds: [suggestionEmbed],
                    components: [
                        suggestionsButtonRow
                    ]
                })

                await suggestionMessage.react('👍')
                await suggestionMessage.react('👎')

                const SuggestEmbed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${message.author}, jouw suggestie is succesvol geschreven in ${channel}`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                await message.channel.send({ embeds: [SuggestEmbed] }).then((SuggestEmbed) => {
                    setTimeout(() => {
                        SuggestEmbed.delete()
                    }, 5000);
                })

            } catch (err) {
                return console.log(err)
            }

        } else {

            const embed1 = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`🚫 Om een suggestie toe te voegen doe dan: \`${prefix}discordsuggest met jouw suggestie hier\``)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            return message.channel.send({ embeds: [embed1] })

        }




    }
}

// © Bot created by Sides Hosting & Dev