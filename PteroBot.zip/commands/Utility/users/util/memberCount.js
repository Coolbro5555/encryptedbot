const { MessageEmbed, Message } = require('discord.js')
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix

module.exports = {
    name: "membercount",
    description: "kijkt hoeveel leden de server heeft",
    aliases: ["mc"],

    run: async (client, message, args) => {

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setAuthor({ name: `${message.guild.name} - Membercount`, iconURL: `${gif}` })
            .setDescription(`\`\`\`${message.guild.memberCount}\`\`\``)
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        message.channel.send({ embeds: [embed] })
    }
}

// © Bot created by Sides Hosting & Dev