const { MessageEmbed } = require('discord.js')
const { user } = require('../../../../index')
const client = require('../../../../index')
const schema = require('../../../../models/userConfig')
const gif = require('../../../../utils.json').gif
const color = require('../../../../utils.json').color
const footer = require('../../../../utils.json').footer
const prefix = require('../../../../config.json').prefix

module.exports = {
    name: "leaderboard",
    description: "xp leaderboard",
    aliases: ['lb'],

    run: async (client, message, args) => {

        try {
            let data = await schema.find({})
            let members = []

            for (let obj of data) {
                if (message.guild.members.cache
                    .map((member) => member.id)
                    .includes(obj.user)) members.push(obj)
            }

            const embed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setAuthor({ name: `${message.guild.name} - Leaderboard`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()

            members = members.sort(function (b, a) {
                return a.xp - b.xp

            })

            members = members.filter(function BigEnough(value) {
                return value.level > 0
            })

            let pos = 0
            for (let obj of members) {
                pos++
                if (obj.user === message.member.id) {
                    embed.setFooter({ text: `Je staat #${pos} in het leaderboard` })
                }
            }

            members = members.slice(0, 10)
            let desc = '';

            for (let i = 0; i < members.length; i++) {
                let user = client.users.cache.get(members[i].user)
                if (!user) return;
                let bal = members[i].level
                desc += `**${i + 1}.** ${user.tag} - Level: **${bal}**\n`
            }

            embed.setDescription(desc)
            message.reply({ embeds: [embed] })

        } catch (error) {
            console.log(error)
            const kaas = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Er ging iets fout, contacteer staff om dit probleem op te lossen!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
            message.channel.send({embeds: [kaas]})
        }
    }
}

// © Bot created by Sides Hosting & Dev