const { MessageEmbed } = require('discord.js')
const client = require('../../../../../index')
const users = require('../../../../../models/gamesSchema')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {
    name: "coin",
    description: "kop of munt minigame",
    aliases: ['kopofmunt', 'coinflip'],

    run: async (client, message, args) => {

        const user = message.author;
        const gamesSchemaData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, coins: 0 })

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription('Je voert dit command uit door \`.coin <kop of munt> <getalwaarde van jouw inzet>\` te doen')
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[0]) return message.channel.send({ embeds: [embed1] })

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription('Je voert dit command uit door \`.coin <kop of munt> <getalwaarde van jouw inzet>\` te doen')
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[1]) return message.channel.send({ embeds: [embed2] })



        // Als jouw eigen coins lager zijn dan jouw args[1], doe niks

        const embed4 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.author}, je kunt niet **${args[1]}** coin(s) inzetten, aangezien je maar **${gamesSchemaData.coins}** coin(s) hebt!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (args[1] > gamesSchemaData.coins) return message.channel.send({ embeds: [embed4] })

        const embed5 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.author}, je kunt niet **${args[1]}** coin(s) inzetten, aangezien je maar **${gamesSchemaData.coins}** coin(s) hebt!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (args[1] == 0) return message.channel.send({ embeds: [embed5] })

        const embed6 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.author}, je kunt geen waarde inzetten wat een kommagetal bevat!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (args[1].includes('.')) return message.channel.send({ embeds: [embed6] })

        const embed7 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.author}, het limiet bij kop of munt staat op 100, je kunt dus niet meer dan 100 coins inzetten op kop of munt!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (args[1] > 101) return message.channel.send({ embeds: [embed7] })

        const embed8 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.author}, je kunt alleen maar een nummer als getal opgeven!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (Number.isNaN(+args[1])) return message.channel.send({ embeds: [embed8] })

        const options = [
            'kop',
            'munt',
        ]

        var result = options[Math.floor(Math.random() * options.length)]
        var winst = parseInt(args[1])
        var verlies = parseInt(args[1]) + 2

        if (args[0].toUpperCase() === 'KOP') {

            if (result === 'kop') {

                gamesSchemaData.coins += winst
                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                const embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`💰 | Gefeliciteerd ${message.author} je hebt **${winst}** coin(s) gewonnen`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (result === 'munt') {

                if (gamesSchemaData.coins - verlies < 0) {

                    await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                        coins: 0
                    })

                    const embed = new MessageEmbed()
                        .setColor(color)
                        .setThumbnail(gif)
                        .setDescription(`❌ | Helaas ${message.author} je hebt **${winst}** coin(s) verloren!`)
                        .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                        .setFooter({ text: `${footer}` })
                        .setTimestamp()
                    return message.channel.send({ embeds: [embed] })
                }

                gamesSchemaData.coins -= verlies
                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                const embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`❌ | Helaas ${message.author} je hebt **${winst}** coin(s) verloren!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

        }

        if (args[0].toUpperCase() === 'MUNT') {

            if (result === 'munt') {

                gamesSchemaData.coins += winst
                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                const embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`💰 | Gefeliciteerd ${message.author} je hebt **${winst}** coin(s) gewonnen!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (result === 'kop') {

                if (gamesSchemaData.coins - verlies < 0) {

                    await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                        coins: 0
                    })

                    const embed = new MessageEmbed()
                        .setColor(color)
                        .setThumbnail(gif)
                        .setDescription(`❌ | Helaas ${message.author} je hebt **${winst}** coin(s) verloren!`)
                        .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                        .setFooter({ text: `${footer}` })
                        .setTimestamp()
                    return message.channel.send({ embeds: [embed] })
                }

                gamesSchemaData.coins -= verlies
                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                const embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`❌ | Helaas ${message.author} je hebt **${winst}** coin(s) verloren!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

        }
    }
}

// © Bot created by Sides Hosting & Dev