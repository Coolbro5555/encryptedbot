const { MessageEmbed } = require('discord.js')
const client = require('../../../../../index')
const users = require('../../../../../models/gamesSchema')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {
    name: "steenpapierschaar",
    aliases: ['sps'],
    description: "steen papier schaar commands",
    cooldown: 60,

    run: async (client, message, args) => {

        // Schema zooi
        const user = message.author;

        // Alle andere zooi
        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription('Je voert dit command uit door \`.sps <steen, papier of schaar>\` te doen')
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[0]) return message.reply({ embeds: [embed1] })

        const options = [
            'steen',
            'papier',
            'schaar'
        ]

        const gamesSchemaData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, coins: 0 });
        var output = options[Math.floor(Math.random() * options.length)];

        if (args[0].toUpperCase() == 'STEEN') {

            if (output == 'schaar') {
                gamesSchemaData.coins += 5;

                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`💰 | Gefeliciteerd ${message.author} je hebt **5** coin(s) gewonnen`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (output == 'steen') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`🔗 | Het is gelijk, ${message.author}`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (output == 'papier') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`❌ | Helaas ${message.author} je hebt verloren!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }
        }

        if (args[0].toUpperCase() == 'PAPIER') {

            if (output == 'papier') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`🔗 | Het is gelijk, ${message.author}`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (output == 'steen') {
                gamesSchemaData.coins += 5;

                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`💰 | Gefeliciteerd ${message.author} je hebt **5** coin(s) gewonnen`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }


            if (output == 'schaar') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`❌ | Helaas ${message.author} je hebt verloren!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }
        }

        if (args[0].toUpperCase() == 'SCHAAR') {

            if (output == 'steen') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`❌ | Helaas ${message.author} je hebt verloren!`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (output == 'schaar') {
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`🔗 | Het is gelijk, ${message.author}`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }

            if (output == 'papier') {
                gamesSchemaData.coins += 5;

                await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
                    coins: gamesSchemaData.coins
                })
                let embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`💰 | Gefeliciteerd ${message.author} je hebt **5** coin(s) gewonnen`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.channel.send({ embeds: [embed] })
            }
        }
    }


}

// © Bot created by Sides Hosting & Dev