const {
    Message,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu
} = require('discord.js');
const users = require('../../../../../models/gamesSchema')
const Discord = require('discord.js')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {
    name: "boterkaaseieren",
    description: "boter kaas en eieren command",
    aliases: ['ttt', 'tictactoe'],

    run: async (client, message, args) => {

        async function tictactoe(message, options = []) {

            const user = message.mentions.members.first() || message.author;
            const gamesSchemaData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, coins: 0 })
            //als een user heeft gewonnen, krijgt hij 4 coins

            return new Promise(async (resolve) => {
                try {
                    const { client } = message
                    let opponent
                    var errorEmbed = new MessageEmbed()
                        .setColor(color)
                        .setThumbnail(gif)
                        .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                        .setFooter({ text: `${footer}` })

                    var succesEmbed = new MessageEmbed()
                        .setColor(color)
                        .setThumbnail(gif)
                        .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                        .setFooter({ text: `${footer}` })
                        

                    if (message.commandId) {
                        opponent = message.options.getUser(options.userSlash || 'user')

                        if (!opponent)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Tag de gene tegen wie je wilt spelen. Doe dat zo \`.ttt @user\`')] })

                        if (opponent.bot)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Je kunt niet tegen een bot spelen!')] })

                        if (opponent.id == (message.user ? message.user : message.author).id)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Je kunt niet tegen jezelf spelen!')] })

                    } else if (!message.commandId) {
                        opponent = message.mentions.members.first()?.user

                        if (!opponent)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Tag de gene tegen wie je wilt spelen. Doe dat zo \`.ttt @user\`')] })

                        if (opponent.bot)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Je kunt niet tegen een bot spelen!')] })


                        if (opponent.id === message.member.id)
                            return message.channel.send({ embeds: [errorEmbed.setDescription('Je kunt niet tegen 2 spelers spelen')] })
                    }

                    if (options.credit === false) {
                        foot = options.embedFoot || 'Denk eraan om te winnen ;)'
                    } else {
                        foot = `${footer}`
                    }

                    let acceptEmbed = new Discord.MessageEmbed()
                        .setTitle(`Aan het wachten op ${opponent.tag}, totdat hij accepteert!`)
                        .setAuthor({
                            name:
                                `${(message.user ? message.user : message.author).tag}`,
                            iconURL: `${(message.user ? message.user : message.author).displayAvatarURL()}`
                        })
                        .setColor(color)
                        .setTimestamp()
                        .setFooter({ text: `${foot}` })

                    let accept = new Discord.MessageButton()
                        .setLabel('Accepteren')
                        .setStyle('SUCCESS')
                        .setCustomId('acceptttt')

                    let decline = new Discord.MessageButton()
                        .setLabel('Afwijzen')
                        .setStyle('DANGER')
                        .setCustomId('declinettt')

                    let accep = new Discord.MessageActionRow().addComponents([
                        accept,
                        decline
                    ])

                    let m

                    if (message.commandId) {
                        m = await message.followUp({
                            content: 'Hey <@' + opponent.id + '>. Je bent uitgedaagd voor een potje boter kaas en eieren',
                            embeds: [acceptEmbed],
                            components: [accep]
                        })
                    } else if (!message.commandId) {
                        m = await message.reply({
                            content: 'Hey <@' + opponent.id + '>. Je bent uitgedaagd voor een potje boter kaas en eieren',
                            embeds: [acceptEmbed],
                            components: [accep]
                        })
                    }
                    const collector = m.createMessageComponentCollector({
                        type: 'BUTTON',
                        time: 30000
                    })
                    collector.on('collect', async (button) => {
                        if (button.user.id !== opponent.id)
                            return button.reply({
                                embeds: [errorEmbed.setDescription('Je kunt niet spelen als je niet bent uitgedaagd!')],
                                ephemeral: true
                            })

                        if (button.customId == 'declinettt') {
                            button.deferUpdate()
                            return collector.stop('decline')
                        } else if (button.customId == 'acceptttt') {
                            collector.stop()
                            if (message.commandId) {
                                button.message.delete()
                            }

                            let fighters = [
                                (message.user ? message.user : message.author).id,
                                opponent.id
                            ].sort(() => (Math.random() > 0.5 ? 1 : -1))

                            let x_emoji = options.xEmoji || '❌'
                            let o_emoji = options.oEmoji || '⭕'

                            let dashmoji = options.idleEmoji || '➖'

                            let args = {
                                user: 0,
                                a1: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                a2: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                a3: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                b1: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                b2: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                b3: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                c1: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                c2: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                },
                                c3: {
                                    style: 'SECONDARY',
                                    emoji: dashmoji,
                                    disabled: false
                                }
                            }
                            const { MessageActionRow, MessageButton } = require('discord.js')

                            let epm = new Discord.MessageEmbed()
                                .setTitle('Boter kaas en eieren..')
                                .setColor(options.embedColor || 0x075fff)
                                .setFooter({ text: `${foot}` })
                                .setTimestamp()

                            let msg
                            if (message.commandId) {
                                msg = await message.followUp({
                                    embeds: [
                                        epm.setDescription(
                                            `Wachten op tegenstander | <@!${args.userid}>, Jouw emoji: ${client.emojis.cache.get(o_emoji) || '⭕'
                                            }`
                                        )
                                    ]
                                })
                            } else if (!message.commandId) {
                                msg = await button.message.edit({
                                    embeds: [
                                        epm.setDescription(
                                            `Wachten op tegenstander | <@!${args.userid}>, Jouw emoji: ${client.emojis.cache.get(o_emoji) || '⭕'
                                            }`
                                        )
                                    ]
                                })
                            }

                            await ttt(msg)

                            async function ttt(m) {
                                args.userid = fighters[args.user]
                                let won = {
                                    '<:O_:863314110560993340>': false,
                                    '<:X_:863314044781723668>': false
                                }

                                let a1 = new MessageButton()
                                    .setStyle(args.a1.style)
                                    .setEmoji(args.a1.emoji)
                                    .setCustomId('a1')
                                    .setDisabled(args.a1.disabled)
                                let a2 = new MessageButton()
                                    .setStyle(args.a2.style)
                                    .setEmoji(args.a2.emoji)
                                    .setCustomId('a2')
                                    .setDisabled(args.a2.disabled)
                                let a3 = new MessageButton()
                                    .setStyle(args.a3.style)
                                    .setEmoji(args.a3.emoji)
                                    .setCustomId('a3')
                                    .setDisabled(args.a3.disabled)
                                let b1 = new MessageButton()
                                    .setStyle(args.b1.style)
                                    .setEmoji(args.b1.emoji)
                                    .setCustomId('b1')
                                    .setDisabled(args.b1.disabled)
                                let b2 = new MessageButton()
                                    .setStyle(args.b2.style)
                                    .setEmoji(args.b2.emoji)
                                    .setCustomId('b2')
                                    .setDisabled(args.b2.disabled)
                                let b3 = new MessageButton()
                                    .setStyle(args.b3.style)
                                    .setEmoji(args.b3.emoji)
                                    .setCustomId('b3')
                                    .setDisabled(args.b3.disabled)
                                let c1 = new MessageButton()
                                    .setStyle(args.c1.style)
                                    .setEmoji(args.c1.emoji)
                                    .setCustomId('c1')
                                    .setDisabled(args.c1.disabled)
                                let c2 = new MessageButton()
                                    .setStyle(args.c2.style)
                                    .setEmoji(args.c2.emoji)
                                    .setCustomId('c2')
                                    .setDisabled(args.c2.disabled)
                                let c3 = new MessageButton()
                                    .setStyle(args.c3.style)
                                    .setEmoji(args.c3.emoji)
                                    .setCustomId('c3')
                                    .setDisabled(args.c3.disabled)
                                let a = new MessageActionRow().addComponents([a1, a2, a3])
                                let b = new MessageActionRow().addComponents([b1, b2, b3])
                                let c = new MessageActionRow().addComponents([c1, c2, c3])
                                let buttons = [a, b, c]

                                if (
                                    args.a1.emoji == o_emoji &&
                                    args.b1.emoji == o_emoji &&
                                    args.c1.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.a2.emoji == o_emoji &&
                                    args.b2.emoji == o_emoji &&
                                    args.c2.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.a3.emoji == o_emoji &&
                                    args.b3.emoji == o_emoji &&
                                    args.c3.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.a1.emoji == o_emoji &&
                                    args.b2.emoji == o_emoji &&
                                    args.c3.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.a3.emoji == o_emoji &&
                                    args.b2.emoji == o_emoji &&
                                    args.c1.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.a1.emoji == o_emoji &&
                                    args.a2.emoji == o_emoji &&
                                    args.a3.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.b1.emoji == o_emoji &&
                                    args.b2.emoji == o_emoji &&
                                    args.b3.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (
                                    args.c1.emoji == o_emoji &&
                                    args.c2.emoji == o_emoji &&
                                    args.c3.emoji == o_emoji
                                )
                                    won['<:O_:863314110560993340>'] = true
                                if (won['<:O_:863314110560993340>'] != false) {
                                    if (args.user == 0) {
                                        let wonner = await client.users
                                            .fetch(fighters[1])
                                            .catch(console.error)
                                        resolve(wonner)

                                        if (options.resultBtn === true)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[1]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                        }) heeft gewonnen!`,
                                                    components: buttons,

                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[1]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                            }) heeft gewonnen!`
                                                        )
                                                    ]
                                                })
                                                .then((m) => {
                                                    m.react('⭕')
                                                })

                                        else if (!options.resultBtn || options.resultBtn === false)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[1]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                        }) heeft gewonnen!`,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[1]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                                }) heeft gewonnen!\n\`\`\`\n${args.a1.emoji
                                                                    .replace(o_emoji, '⭕')
                                                                    .replace(x_emoji, '❌')} | ${args.a2.emoji
                                                                        .replace(o_emoji, '⭕')
                                                                        .replace(x_emoji, '❌')} | ${args.a3.emoji
                                                                            .replace(o_emoji, '⭕')
                                                                            .replace(x_emoji, '❌')}\n${args.b1.emoji
                                                                                .replace(o_emoji, '⭕')
                                                                                .replace(x_emoji, '❌')} | ${args.b2.emoji
                                                                                    .replace(o_emoji, '⭕')
                                                                                    .replace(x_emoji, '❌')} | ${args.b3.emoji
                                                                                        .replace(o_emoji, '⭕')
                                                                                        .replace(x_emoji, '❌')}\n${args.c1.emoji
                                                                                            .replace(o_emoji, '⭕')
                                                                                            .replace(x_emoji, '❌')} | ${args.c2.emoji
                                                                                                .replace(o_emoji, '⭕')
                                                                                                .replace(x_emoji, '❌')} | ${args.c3.emoji
                                                                                                    .replace(o_emoji, '⭕')
                                                                                                    .replace(x_emoji, '❌')}\n\`\`\``.replaceAll(
                                                                                                        dashmoji,
                                                                                                        '➖'
                                                                                                    )
                                                        )
                                                    ],
                                                    components: []
                                                })
                                                .then((m) => {
                                                    m.react('⭕')
                                                })

                                    } else if (args.user == 1) {
                                        let wonner = await client.users
                                            .fetch(fighters[0])
                                            .catch(console.error)
                                        resolve(wonner)

                                        if (options.resultBtn === true)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[0]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                        }) heeft gewonnen!`,
                                                    components: buttons,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[0]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                            }) heeft gewonnen!`
                                                        )
                                                    ]
                                                })
                                                .then((m) => {
                                                    m.react('⭕')
                                                })
                                        else if (!options.resultBtn || options.resultBtn === false)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[0]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                        }) heeft gewonnen!`,

                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[0]}> (${client.emojis.cache.get(o_emoji) || '⭕'
                                                                }) heeft gewonnen!\n\`\`\`\n${args.a1.emoji
                                                                    .replace(o_emoji, '⭕')
                                                                    .replace(x_emoji, '❌')} | ${args.a2.emoji
                                                                        .replace(o_emoji, '⭕')
                                                                        .replace(x_emoji, '❌')} | ${args.a3.emoji
                                                                            .replace(o_emoji, '⭕')
                                                                            .replace(x_emoji, '❌')}\n${args.b1.emoji
                                                                                .replace(o_emoji, '⭕')
                                                                                .replace(x_emoji, '❌')} | ${args.b2.emoji
                                                                                    .replace(o_emoji, '⭕')
                                                                                    .replace(x_emoji, '❌')} | ${args.b3.emoji
                                                                                        .replace(o_emoji, '⭕')
                                                                                        .replace(x_emoji, '❌')}\n${args.c1.emoji
                                                                                            .replace(o_emoji, '⭕')
                                                                                            .replace(x_emoji, '❌')} | ${args.c2.emoji
                                                                                                .replace(o_emoji, '⭕')
                                                                                                .replace(x_emoji, '❌')} | ${args.c3.emoji
                                                                                                    .replace(o_emoji, '⭕')
                                                                                                    .replace(x_emoji, '❌')}\n\`\`\``.replaceAll(
                                                                                                        dashmoji,
                                                                                                        '➖'
                                                                                                    )
                                                        )
                                                    ],
                                                    components: []
                                                })
                                                .then((m) => {
                                                    m.react('⭕')
                                                })
                                    }
                                }
                                if (
                                    args.a1.emoji == x_emoji &&
                                    args.b1.emoji == x_emoji &&
                                    args.c1.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.a2.emoji == x_emoji &&
                                    args.b2.emoji == x_emoji &&
                                    args.c2.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.a3.emoji == x_emoji &&
                                    args.b3.emoji == x_emoji &&
                                    args.c3.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.a1.emoji == x_emoji &&
                                    args.b2.emoji == x_emoji &&
                                    args.c3.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.a3.emoji == x_emoji &&
                                    args.b2.emoji == x_emoji &&
                                    args.c1.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.a1.emoji == x_emoji &&
                                    args.a2.emoji == x_emoji &&
                                    args.a3.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.b1.emoji == x_emoji &&
                                    args.b2.emoji == x_emoji &&
                                    args.b3.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (
                                    args.c1.emoji == x_emoji &&
                                    args.c2.emoji == x_emoji &&
                                    args.c3.emoji == x_emoji
                                )
                                    won['<:X_:863314044781723668>'] = true
                                if (won['<:X_:863314044781723668>'] != false) {
                                    if (args.user == 0) {
                                        let wonner = await client.users
                                            .fetch(fighters[1])
                                            .catch(console.error)
                                        resolve(wonner)

                                        if (options.resultBtn === true)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[1]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                        }) heeft gewonnen!`,
                                                    components: buttons,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[1]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                            }) heeft gewonnen!`
                                                        )
                                                    ]
                                                })
                                                .then((m) => {
                                                    m.react('❌')
                                                })
                                        else if (!options.resultBtn || options.resultBtn === false)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[1]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                        }) heeft gewonnen`,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[1]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                                }) heeft gewonnen!\n\`\`\`\n${args.a1.emoji
                                                                    .replace(o_emoji, '⭕')
                                                                    .replace(x_emoji, '❌')} | ${args.a2.emoji
                                                                        .replace(o_emoji, '⭕')
                                                                        .replace(x_emoji, '❌')} | ${args.a3.emoji
                                                                            .replace(o_emoji, '⭕')
                                                                            .replace(x_emoji, '❌')}\n${args.b1.emoji
                                                                                .replace(o_emoji, '⭕')
                                                                                .replace(x_emoji, '❌')} | ${args.b2.emoji
                                                                                    .replace(o_emoji, '⭕')
                                                                                    .replace(x_emoji, '❌')} | ${args.b3.emoji
                                                                                        .replace(o_emoji, '⭕')
                                                                                        .replace(x_emoji, '❌')}\n${args.c1.emoji
                                                                                            .replace(o_emoji, '⭕')
                                                                                            .replace(x_emoji, '❌')} | ${args.c2.emoji
                                                                                                .replace(o_emoji, '⭕')
                                                                                                .replace(x_emoji, '❌')} | ${args.c3.emoji
                                                                                                    .replace(o_emoji, '⭕')
                                                                                                    .replace(x_emoji, '❌')}\n\`\`\``.replaceAll(
                                                                                                        dashmoji,
                                                                                                        '➖'
                                                                                                    )
                                                        )
                                                    ],
                                                    components: []
                                                })
                                                .then((m) => {
                                                    m.react('❌')
                                                })
                                    } else if (args.user == 1) {
                                        let wonner = await client.users
                                            .fetch(fighters[0])
                                            .catch(console.error)
                                        resolve(wonner)

                                        if (options.resultBtn === true)
                                            return m
                                                .edit({
                                                    content: `<@${fighters[0]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                        }) heeft gewonnen!`,
                                                    components: buttons,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[0]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                            }) heeft gewonnen!`
                                                        )
                                                    ]
                                                })
                                                .then((m) => {
                                                    m.react('❌')
                                                })
                                        else
                                            return m
                                                .edit({
                                                    content: `<@${fighters[0]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                        }) heeft gewonnen!`,
                                                    embeds: [
                                                        epm.setDescription(
                                                            `<@!${fighters[0]}> (${client.emojis.cache.get(x_emoji) || '❌'
                                                                }) heeft gewonnen!\n\`\`\`\n${args.a1.emoji
                                                                    .replace(o_emoji, '⭕')
                                                                    .replace(x_emoji, '❌')} | ${args.a2.emoji
                                                                        .replace(o_emoji, '⭕')
                                                                        .replace(x_emoji, '❌')} | ${args.a3.emoji
                                                                            .replace(o_emoji, '⭕')
                                                                            .replace(x_emoji, '❌')}\n${args.b1.emoji
                                                                                .replace(o_emoji, '⭕')
                                                                                .replace(x_emoji, '❌')} | ${args.b2.emoji
                                                                                    .replace(o_emoji, '⭕')
                                                                                    .replace(x_emoji, '❌')} | ${args.b3.emoji
                                                                                        .replace(o_emoji, '⭕')
                                                                                        .replace(x_emoji, '❌')}\n${args.c1.emoji
                                                                                            .replace(o_emoji, '⭕')
                                                                                            .replace(x_emoji, '❌')} | ${args.c2.emoji
                                                                                                .replace(o_emoji, '⭕')
                                                                                                .replace(x_emoji, '❌')} | ${args.c3.emoji
                                                                                                    .replace(o_emoji, '⭕')
                                                                                                    .replace(x_emoji, '❌')}\n\`\`\``.replaceAll(
                                                                                                        dashmoji,
                                                                                                        '➖'
                                                                                                    )
                                                        )
                                                    ],
                                                    components: []
                                                })
                                                .then((m) => {
                                                    m.react('❌')
                                                })
                                    }
                                }

                                m.edit({
                                    content: `<@${args.userid}>`,
                                    embeds: [
                                        epm.setDescription(
                                            `Wachten op tegenstander | <@!${args.userid}> | Jouw emoji: ${args.user == 0
                                                ? `${client.emojis.cache.get(o_emoji) || '⭕'}`
                                                : `${client.emojis.cache.get(x_emoji) || '❌'}`
                                            }`
                                        )
                                    ],
                                    components: [a, b, c]
                                })

                                const collector = m.createMessageComponentCollector({
                                    componentType: 'BUTTON',
                                    max: 1,
                                    time: 30000
                                })

                                collector.on('collect', (b) => {
                                    if (b.user.id !== args.userid) {
                                        b.reply({
                                            content: 'You cant play now',
                                            ephemeral: true
                                        })

                                        ttt(m)
                                    } else {
                                        if (args.user == 0) {
                                            args.user = 1
                                            args[b.customId] = {
                                                style: 'SUCCESS',
                                                emoji: o_emoji,
                                                disabled: true
                                            }
                                        } else {
                                            args.user = 0
                                            args[b.customId] = {
                                                style: 'DANGER',
                                                emoji: x_emoji,
                                                disabled: true
                                            }
                                        }
                                        b.deferUpdate()
                                        const map = (obj, fun) =>
                                            Object.entries(obj).reduce(
                                                (prev, [key, value]) => ({
                                                    ...prev,
                                                    [key]: fun(key, value)
                                                }),
                                                {}
                                            )
                                        const objectFilter = (obj, predicate) =>
                                            Object.keys(obj)
                                                .filter((key) => predicate(obj[key]))
                                                .reduce((res, key) => ((res[key] = obj[key]), res), {})
                                        let Brgs = objectFilter(
                                            map(args, (_, fruit) => fruit.emoji == dashmoji),
                                            (num) => num == true
                                        )

                                        if (Object.keys(Brgs).length == 0) {
                                            if (
                                                args.a1.emoji == o_emoji &&
                                                args.b1.emoji == o_emoji &&
                                                args.c1.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.a2.emoji == o_emoji &&
                                                args.b2.emoji == o_emoji &&
                                                args.c2.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.a3.emoji == o_emoji &&
                                                args.b3.emoji == o_emoji &&
                                                args.c3.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.a1.emoji == o_emoji &&
                                                args.b2.emoji == o_emoji &&
                                                args.c3.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.a3.emoji == o_emoji &&
                                                args.b2.emoji == o_emoji &&
                                                args.c1.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.a1.emoji == o_emoji &&
                                                args.a2.emoji == o_emoji &&
                                                args.a3.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.b1.emoji == o_emoji &&
                                                args.b2.emoji == o_emoji &&
                                                args.b3.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true
                                            if (
                                                args.c1.emoji == o_emoji &&
                                                args.c2.emoji == o_emoji &&
                                                args.c3.emoji == o_emoji
                                            )
                                                won['<:O_:863314110560993340>'] = true

                                            if (won['<:O_:863314110560993340>'] == true) return ttt(m)
                                            else if (won['<:X_:863314044781723668>'] == true) return
                                            else {
                                                ttt(m)

                                                if (options.resultBtn === true)
                                                    return m
                                                        .edit({
                                                            content: 'Gelijk',
                                                            embeds: [epm.setDescription(`Het is gelijk!`)]
                                                        })
                                                        .then((m) => {
                                                            m.react(dashmoji)
                                                        })
                                                else
                                                    return m
                                                        .edit({
                                                            content: 'Gelijk',
                                                            embeds: [
                                                                epm.setDescription(
                                                                    `Het is gelijk!\n\`\`\`\n${args.a1.emoji
                                                                        .replace(o_emoji, '⭕')
                                                                        .replace(x_emoji, '❌')} | ${args.a2.emoji
                                                                            .replace(o_emoji, '⭕')
                                                                            .replace(x_emoji, '❌')} | ${args.a3.emoji
                                                                                .replace(o_emoji, '⭕')
                                                                                .replace(x_emoji, '❌')}\n${args.b1.emoji
                                                                                    .replace(o_emoji, '⭕')
                                                                                    .replace(x_emoji, '❌')} | ${args.b2.emoji
                                                                                        .replace(o_emoji, '⭕')
                                                                                        .replace(x_emoji, '❌')} | ${args.b3.emoji
                                                                                            .replace(o_emoji, '⭕')
                                                                                            .replace(x_emoji, '❌')}\n${args.c1.emoji
                                                                                                .replace(o_emoji, '⭕')
                                                                                                .replace(x_emoji, '❌')} | ${args.c2.emoji
                                                                                                    .replace(o_emoji, '⭕')
                                                                                                    .replace(x_emoji, '❌')} | ${args.c3.emoji
                                                                                                        .replace(o_emoji, '⭕')
                                                                                                        .replace(x_emoji, '❌')}\n\`\`\``.replaceAll(
                                                                                                            dashmoji,
                                                                                                            '➖'
                                                                                                        )
                                                                )
                                                            ],
                                                            components: []
                                                        })
                                                        .then((m) => {
                                                            m.react(dashmoji)
                                                        })
                                                        .catch(() => { })
                                            }
                                        }

                                        ttt(m)
                                    }
                                })
                                collector.on('end', (collected, reason) => {
                                    if (collected.size === 0 && reason == 'time')
                                        m.edit({
                                            content: `<@!${args.userid}> didn\'t react in time! (30s)`,
                                            components: []
                                        })
                                })
                            }
                        }
                    })

                    collector.on('end', (collected, reason) => {
                        if (reason == 'time') {
                            let embed = new Discord.MessageEmbed()
                                .setTitle('Uitdaging niet geaccepteerd')
                                .setAuthor({
                                    name:
                                        `${(message.user ? message.user : message.author).tag}`,
                                    iconURL: `${(message.user ? message.user : message.author).displayAvatarURL()}`
                                })
                                .setColor(options.timeoutEmbedColor || 0xc90000)
                                .setFooter({ text: `${foot}` })
                                .setDescription('Te laat gereageerd!\nTijd limiet: 30s')
                            m.edit({
                                content: '<@' + opponent.id + '> heeft de uitdaging niet geaccepteerd binnen de tijd',
                                embeds: [embed],
                                components: []
                            })
                        }
                        if (reason == 'decline') {
                            let embed = new Discord.MessageEmbed()
                                .setTitle('Game afgewezen!')
                                .setAuthor({
                                    name:
                                        `${(message.user ? message.user : message.author).tag}`,
                                    iconURL: `${(message.user ? message.user : message.author).displayAvatarURL()}`
                                })
                                .setColor(options.timeoutEmbedColor || 0xc90000)
                                .setFooter({ text: `${foot}` })
                                .setDescription(`${opponent.user.tag} heeft jouw game niet geaccepteerd`)
                            m.edit({
                                embeds: [embed],
                                components: []
                            })
                        }
                    })
                } catch (err) {
                    console.log(`Error Occured. | tictactoe | Error: ${err.stack}`)
                }
            })
        }

        module.exports = tictactoe
        tictactoe(message)


    }
}

// © Bot created by Sides Hosting & Dev