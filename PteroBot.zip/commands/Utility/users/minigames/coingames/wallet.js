const { MessageEmbed } = require('discord.js')
const client = require('../../../../../index')
const users = require('../../../../../models/gamesSchema')
const ms = require('ms')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {

    name: "coins",
    description: "kijkt hoeveel coins je hebt",
    aliases: ['balance', 'bal', 'b'],

    run: async (client, message, args) => {

        const user = message.mentions.members.first() || message.author;
        const gamesSchemaData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, coins: 0 })

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${user} heeft een balance van **${gamesSchemaData.coins}**`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        return message.channel.send({ embeds: [embed] })
    }
}

// © Bot created by Sides Hosting & Dev