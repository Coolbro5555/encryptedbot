const { MessageEmbed } = require('discord.js')
const { user } = require('../../../../../index')
const client = require('../../../../../index')
const gamesSchema = require('../../../../../models/gamesSchema')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {
    name: "minigamesleaderboard",
    aliases: ['mlb'],
    description: "leaderboard voor de minigames",
    guildCooldown: 300,

    run: async (client, message, args) => {

        try {
            let data = await gamesSchema.find({})
            let members = []

            for (let obj of data) {
                if (message.guild.members.cache
                    .map((member) => member.id)
                    .includes(obj.user)) members.push(obj)
            }

            const embed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`${message.guild.name} - Minigames Leaderboard`)
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()

            members = members.sort(function (b, a) {
                return a.coins - b.coins

            })

            members = members.filter(function BigEnough(value) {
                return value.coins > 0
            })

            let pos = 0
            for (let obj of members) {
                pos++
                if (obj.user === message.member.id) {
                    embed.setFooter({ text: `Je staat #${pos} in het leaderboard` })
                }
            }

            members = members.slice(0, 15)
            let desc = '';

            for (let i = 0; i < members.length; i++) {
                let user = client.users.cache.get(members[i].user)
                if (!user) return;
                let bal = members[i].coins
                desc += `**${i + 1}.** ${user.tag} - Coins: **${bal}**\n`
            }

            embed.setDescription(desc)
            message.reply({ embeds: [embed] })

        } catch (error) {
            console.log(error)
            const kaas = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Er ging iets fout, contacteer staff om dit probleem op te lossen!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
            return message.channel.send({embeds: [kaas]})
        }
    }
}

// © Bot created by Sides Hosting & Dev