const { MessageEmbed } = require('discord.js')
const client = require('../../../../../index')
const users = require('../../../../../models/gamesSchema')
const gif = require('../../../../../utils.json').gif
const color = require('../../../../../utils.json').color
const footer = require('../../../../../utils.json').footer
const prefix = require('../../../../../utils.json').prefix


module.exports = {

    name: "removecoins",
    description: "coins weghalen bij een user",
    aliases: ['rcoins', 'rcoin'],

    run: async (client, message, args) => {

        const user = message.mentions.members.first() || message.author;
        const gamesSchemaData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, coins: 0 })

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription('Je bent vergeten om de **user** te vermelden wie je coins wilt geven')
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[0]) return message.channel.send({ embeds: [embed1] })

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription('Je bent vergeten om de **hoeveelheid** coins mee te geven')
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[1]) return message.channel.send({ embeds: [embed2] })


        var win = parseInt(args[1])
        gamesSchemaData.coins -= win
        await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
            coins: gamesSchemaData.coins
        })
        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`Er zijn ${args[1]} coin(s) afgepakt van ${user}`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        return message.channel.send({ embeds: [embed] })
    }

}


// © Bot created by Sides Hosting & Dev