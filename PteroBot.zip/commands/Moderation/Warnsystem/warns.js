const {
    Client,
    Message,
    MessageEmbed
} = require('discord.js');
const warndb = require('../../../models/warndb')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'warns',
    description: "laat alle warns van een persoon zien",

    run: async (client, message, args, Discord) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const user = message.mentions.members.first() || message.author;

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Geef een gebruiker op, doe dat zo: \`${prefix}warns\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!user) return message.channel.send({ embeds: [embed2] })

        warndb.findOne({
            guild: message.guild.id,
            user: user.id
        }, async (err, data) => {
            if (err) throw err
            if (data) {
                const e = data.content.map(
                    (w, i) => `\n\`${i + 1}\` - Moderator: ${message.guild.members.cache.get(w.moderator).user.tag}, Reason: ${w.reason}`
                )
                const embed = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(e.join(' '))
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

                message.channel.send({ embeds: [embed] })

            } else {

                const embed2 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${user} heeft momenteel geen warns!`)
                    .setFields(
                        {
                            name: "User:", value: `${user}`, inline: true
                        },
                        {
                            name: "Moderator:", value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: "Aantal warns:", value: `0`, inline: true
                        }
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                message.channel.send({ embeds: [embed2] })

            }
        })

    }
}

// © Bot created by Sides Hosting & Dev
