const {
    Client,
    Message,
    MessageEmbed
} = require('discord.js');
const warndb = require('../../../models/warndb');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'warn',
    description: "waarschuwt iemand in de server",

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        const embed6 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Geef een gebruiker op, doe dat zo: \`${prefix}warn @user reden\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!user) return message.channel.send({ embeds: [embed6] })

        const reason = args.slice(1).join(" ")
        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Geef een reden mee, doe dat zo: \`${prefix}warn @user reden\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!reason) return message.channel.send({ embeds: [embed2] })

        warndb.findOne({
            guild: message.guild.id,
            user: user.user.id,
        }, async (err, data) => {
            if (err) throw err;
            if (!data) {
                data = new warndb({
                    guild: message.guild.id,
                    user: user.user.id,
                    content: [{
                        moderator: message.author.id,
                        reason: reason
                    }]
                })
            } else {
                const object = {
                    moderator: message.author.id,
                    reason: reason
                }
                data.content.push(object)
            }
            data.save()

            if (data.content.length === 3) {

                const time = 86400000

                const role = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'muted')

                if (!role) {

                    try {

                        message.channel.send('Muted role is not found, attempting to create muted role.')

                        let muterole = await message.guild.roles.create({
                            data: {
                                name: 'muted',
                                permissions: []
                            }
                        });
                        message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                            await channel.createOverwrite(muterole, {
                                SEND_MESSAGES: false,
                                ADD_REACTIONS: false
                            })
                        });
                        const embed4 = new MessageEmbed()
                            .setColor(color)
                            .setDescription('✅ Muterole is aagemaakt')
                        message.channel.send({ embeds: [embed4] })
                    } catch (error) {
                        console.log(error)
                    }
                };
                let role2 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')

                const embed5 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`🚫 ${user} is al gemute`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                if (user.roles.cache.has(role2)) return message.channel.send({ embeds: [embed5] })

                await user.roles.add(role2)
                const warns = data.content.length;

                const embedjee = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${user} is gewaarschuwd met de reden: \`${reason}\``)
                    .addFields(
                        {
                            name: 'User:', value: `${user}`, inline: true
                        },
                        {
                            name: 'Moderator:', value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: 'Aantal warns:', value: `${warns}`, inline: true
                        },
                        {
                            name: 'Belangrijk:', value: `${user.displayName} is nu gemute voor 24h, hierna volgt nog een mute!`, inline: true
                        }
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

                message.channel.send({ embeds: [embedjee] })

                setTimeout(async () => {
                    await user.roles.remove(role2)
                    const embed6 = new MessageEmbed()
                        .setColor(color)
                        .setDescription(`✅ ${user.displayName} is ge-unmute!`)
                    message.channel.send({ embeds: [embed6] })
                }, (time))

            } else if (data.content.length === 4) {

                const timee = 604800000

                const rolee = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'muted')

                if (!rolee) {

                    try {

                        message.channel.send('Muted role is not found, attempting to create muted role.')

                        let muterolee = await message.guild.roles.create({
                            data: {
                                name: 'muted',
                                permissions: []
                            }
                        });
                        message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                            await channel.createOverwrite(muterolee, {
                                SEND_MESSAGES: false,
                                ADD_REACTIONS: false
                            })
                        });
                        const embed4 = new MessageEmbed()
                            .setColor(color)
                            .setDescription('✅ Muterole is aagemaakt')
                        message.channel.send({ embeds: [embed4] })
                    } catch (error) {
                        console.log(error)
                    }
                };
                let rolee2 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')

                const embed5 = new MessageEmbed()
                    .setColor(color)
                    .setDescription('🚫 Member is al gemute!')
                if (user.roles.cache.has(rolee2)) return message.channel.send({ embeds: [embed5] })

                await user.roles.add(rolee2)

                const warns = data.content.length;
                const embedjee = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${user} is gewaarschuwd met de reden: \`${reason}\``)
                    .addFields(
                        {
                            name: 'User:', value: `${user}`, inline: true
                        },
                        {
                            name: 'Moderator:', value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: 'Aantal warns:', value: `${warns}`, inline: true
                        },
                        {
                            name: 'Belangrijk:', value: `${user.displayName} gemute voor 1 week, hierna volgt een ban!`, inline: true
                        }
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

                message.channel.send({ embeds: [embedjee] })


                setTimeout(async () => {
                    await user.roles.remove(role2)
                    const embed6 = new MessageEmbed()
                        .setColor(color)
                        .setDescription(`✅ ${user.displayName} is ge-unmute!`)
                    message.channel.send({ embeds: [embed6] })
                }, (timee))

            } else if (data.content.length === 5) {

                if (user) {

                    if (user.permissions.has('KICK_MEMBERS')) return;

                    const reden = 'Verbannen door teveel warns'

                    await user.ban({
                        reason: reden,
                    }).then(() => {

                        const banEmbed = new MessageEmbed()
                            .setColor(color)
                            .setThumbnail(gif)
                            .setDescription(`**${user}** is verbannen met reden: \`${reden}\``)
                            .addFields(
                                {
                                    name: "User:", value: `${user}`, inline: true
                                },
                                {
                                    name: "Moderator:", value: `${message.author.tag}`, inline: true
                                },
                                {
                                    name: "Tijdsduur:", value: `∞`, inline: true
                                },
                            )
                            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                            .setFooter({ text: `${footer}` })
                            .setTimestamp()

                        message.channel.send({ embeds: [banEmbed] })
                    })

                } else {
                    const embed2 = new MessageEmbed()
                        .setColor(color)
                        .setDescription('🚫 Geen gebruiker gevonden!')
                    message.channel.send({ embeds: [embed2] })
                }

            } else {

                const warns = data.content.length;
                const embedjee = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${user} is gewaarschuwd met de reden: \`${reason}\``)
                    .addFields(
                        {
                            name: 'User:', value: `${user}`, inline: true
                        },
                        {
                            name: 'Moderator:', value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: 'Aantal warns:', value: `${warns}`, inline: true
                        },
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()

                message.channel.send({ embeds: [embedjee] })

            }

        })

    }
}

// © Bot created by Sides Hosting & Dev
