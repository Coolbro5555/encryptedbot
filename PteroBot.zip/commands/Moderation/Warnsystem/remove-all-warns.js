const db = require('../../../models/warndb')
const { MessageEmbed } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'remove-all-warns',
    aliases: ['r-all-warns'],
    description: "verwijdert alle warns van een persoon",

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Geef een gebruiker op, doe dat zo: \`${prefix}remove-all-warns @user\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!user) return message.channel.send({ embeds: [embed2] })

        db.findOne({
            guild: message.guild.id,
            user: user.user.id
        }, async (err, data) => {
            if (err) throw err;
            if (data) {
                const warns = data.content.length;

                await db.findOneAndDelete({
                    user: user.user.id,
                    guild: message.guild.id
                })
                const embed2 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`Alle warns van ${user} zijn verwijderd!`)
                    .setFields(
                        {
                            name: "User:", value: `${user}`, inline: true
                        },
                        {
                            name: "Moderator:", value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: "Aantal warns:", value: `${warns}`, inline: true
                        }
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                message.channel.send({ embeds: [embed2] })
            } else {

                const embed2 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${user} heeft momenteel geen warns!`)
                    .setFields(
                        {
                            name: "User:", value: `${user}`, inline: true
                        },
                        {
                            name: "Moderator:", value: `${message.author.tag}`, inline: true
                        },
                        {
                            name: "Aantal warns:", value: `0`, inline: true
                        }
                    )
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                message.channel.send({ embeds: [embed2] })

            }
        })
    }
}

// © Bot created by Sides Hosting & Dev