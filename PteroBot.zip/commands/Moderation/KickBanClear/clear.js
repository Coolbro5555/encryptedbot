const { MessageEmbed } = require("discord.js")
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: "clear",
    description: "verwijdert een groot aantal berichten",
    aliases: ['purge'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command uit te voeren! Je hebt de permissie \`MANAGE_MESSAGES\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("MANAGE_MESSAGE")) return message.channel.send({ embeds: [embed1] })

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Stuur een nummer tussen de \`1 en 99\`")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!args[0]) return message.channel.send({ embeds: [embed2] }) // when there is no number provider

        const embed3 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Stuur alleen cijfers, geen symbolen")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (isNaN(args[0])) return message.channel.send({ embeds: [embed3] }) // checking if the args is a number

        const embed4 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Ik kan niet meer dan **99 berichten** verwijderen")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (parseInt(args[0]) > 99) return message.channel.send({ embeds: [embed4] }) //Max amount of messages avaible to delete is 99

        await message.channel.bulkDelete(parseInt(args[0]) + 1) // deleting messages
            .catch(err => console.log(err)) // if there are errors it will show them in the console / terminal

        const embed = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`Ik heb **${args[0]}** berichten gedelete!`)
            .addFields(
                {
                    name: "Hoeveelheid:", value: `${args[0]}`, inline: true
                },
                {
                    name: "Moderator:", value: `${message.author.tag}`, inline: true
                },
            )
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        const msg = await message.channel.send({ embeds: [embed] })

            .then(setTimeout(() => msg.delete(), 4000))
    }
}

// © Bot created by Sides Hosting & Dev