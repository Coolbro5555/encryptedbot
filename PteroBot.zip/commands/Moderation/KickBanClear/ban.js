const {
    Client,
    Message,
    MessageEmbed
} = require('discord.js');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'ban',
    description: "verbant iemand van de server",
    aliases: ['ba'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`BAN_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const user = message.mentions.members.first();
        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Stuur een valide user, doe dat zo: \`${prefix}ban @user reden\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!user) return message.channel.send({ embeds: [embed2] })
        if (user.permissions.has('KICK_MEMBERS')) return;

        const reason = args.slice(1).join(" ")
        const embed6 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Stuur een valide reden, doe dat zo: \`${prefix}ban @user reden\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!reason) return message.channel.send({ embeds: [embed6] })

        const datum = new Date().toDateString()

        if (user) {
            user.ban({
                reason: reason + " - " + datum
            }).then(() => {

                const banEmbed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription(`**${user}** is gebanned met reden: \`${reason}\``)
                .addFields(
                    {
                        name: "User:", value: `${user}`, inline: true
                    },
                    {
                        name: "Moderator:", value: `${message.author.tag}`, inline: true
                    },
                    {
                        name: "Tijd:", value: `∞`, inline: true
                    },
                )
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()

                message.channel.send({ embeds: [banEmbed] })

            })
        } else {
            const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Ik kan de gebruiker niet vinden!`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
            message.channel.send({ embeds: [embed1] })
        }

    }
}

// © Bot created by Sides Hosting & Dev