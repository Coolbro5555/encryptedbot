const { Message, MessageEmbed } = require('discord.js')
const ms = require('ms')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'mute',
    description: "geeft iemand een mute voor een onbeperkte tijdsduur",
    aliases: ['m'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Stuur een valide user, doe dat zo: \`${prefix}mute @user\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!Member) return message.channel.send({ embeds: [embed2] })
        const role = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'muted')
        if (!role) {
            try {
                message.channel.send('Muted role is not found, attempting to create muted role.')

                let muterole = await message.guild.roles.create({
                    data: {
                        name: 'muted',
                        permissions: []
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                    })
                });
                message.channel.send('Muted role has sucessfully been created.')
            } catch (error) {
                console.log(error)
            }
        };
        let role2 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')
        const embed3 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Deze user is al gemute`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (Member.roles.cache.has(role2.id)) return message.channel.send({ embeds: [embed3] })
        await Member.roles.add(role2)

        const embed4 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`De user is succesvol gemute!`)
            .addFields(
                {
                    name: "User:", value: `${Member}`, inline: true
                },
                {
                    name: "Moderator:", value: `${message.author.tag}`, inline: true
                },
                {
                    name: "Tijd:", value: `∞`, inline: true
                },
            )
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        message.channel.send({ embeds: [embed4] })
    }
}

// © Bot created by Sides Hosting & Dev