const { Message, MessageEmbed } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: 'unmute',
    description: "unmute iemand",
    aliases: ['un'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()

        if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setDescription("🚫 Member niet gevonden")
        if (!Member) return message.channel.send({ embeds: [embed2] })

        const role = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted');

        await Member.roles.remove(role)

        const embed3 = new MessageEmbed()
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setColor(color)
            .setThumbnail(gif)
            .addFields(
                {
                    name: "User:", value: `${Member}`, inline: true
                },
                {
                    name: "Moderator:", value: `${message.author.tag}`, inline: true
                },
            )
            .setDescription(`✅ ${Member.displayName} is geunmute`)
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        message.channel.send({ embeds: [embed3] })

    }
}

// © Bot created by Sides Hosting & Dev