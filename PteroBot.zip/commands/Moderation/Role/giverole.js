const { discord, MessageActionRow, MessageButton, MessageEmbed } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
  name: "addrole",
  description: "geeft een role aan alle mensen of bots in de server",
  aliases: ["arall", "aroleall", "giveroleall", "addroleall"],

  run: async (client, message, args) => {

    const embed7 = new MessageEmbed()
      .setColor(color)
      .setThumbnail(gif)
      .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`KICK_MEMBERS\` nodig")
      .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
      .setFooter({ text: `${footer}` })
      .setTimestamp()
    if (!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send({ embeds: [embed7] })

    const role =
      message.guild.roles.cache.find(
        role => role.name === args.join(" ").slice(1)
      ) ||
      message.mentions.roles.first() ||
      message.guild.roles.cache.get(args.join(" ").slice(1));

    const embed1 = new MessageEmbed()
      .setColor(color)
      .setThumbnail(gif)
      .setDescription(`🚫 Geef een role mee, doe dat zo \`${prefix}giverole @role\``)
      .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
      .setFooter({ text: `${footer}` })
      .setTimestamp()
    if (!role) return message.channel.send({ embeds: [embed1] })

    if (message.guild.me.roles.highest.comparePositionTo(role) < 0) {
      return message.channel.send(
        ` Mijn role is niet hoog genoeg voor **${role.name
        }** role!`,
        { message }
      );
    }

    if (message.member.roles.highest.comparePositionTo(role) < 0) {
      return message.channel.send({
        embeds: [
          new MessageEmbed().setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Jouw role moet hoger zijn dan de **${role.name
              }** role! Dit pas je in jouw roles in discord aan, door jouw role hoger te zetten dan waarvan je hem tagt.`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()]
      }
      );
    }

    if (!role) {
      return message.channel.send(
        "Geef een bestaande role op",
        { message }
      );
    }
    let type = new MessageActionRow().addComponents(
      new MessageButton()
        .setStyle("SUCCESS")
        .setLabel("Bots")
        .setCustomId("bot"),
      new MessageButton()
        .setStyle("SUCCESS")
        .setLabel("Members")
        .setCustomId("member")
    );
    let embed = new MessageEmbed()
      .setColor(color)
      .setThumbnail(gif)
      .setDescription(`KLik op de soort member waaraan je ${role} wilt geven`)
      .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
      .setFooter({ text: `${footer}` })
      .setTimestamp()

    let msg = await message.channel.send({
      embeds: [embed],
      components: [type]
    });

    let filter = i => i.user.id === message.author.id;
    let collector = msg.createMessageComponentCollector({
      filter
    });

    collector.on("collect", async i => {
      if (i.customId === "member") {
        message.guild.members.cache
          .filter(member => !member.user.bot)
          .map(a => a.roles.add(role));
        msg.delete();
        return message.channel.send({
          embeds: [new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`De role **${role.name}** is toegevoegd bij \`members\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()]
          });
      }

      if (i.customId === "bot") {
        message.guild.members.cache
          .filter(member => member.user.bot)
          .map(a => a.roles.add(role));
        msg.delete();
        return message.channel.send({
          embeds: [new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`De role **${role.name}** is toegevoegd bij \`bots\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()]
          });
      }

    });
  }
};

// © Bot created by Sides Hosting & Dev