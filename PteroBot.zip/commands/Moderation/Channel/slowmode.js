const { MessageEmbed, Message } = require('discord.js')
const ms = require('ms');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: "slowmode",
    description: "past de slowmode aan, zet de slowmode uit/aan",
    aliases: ['s'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`MANAGE_CHANNELS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("MANAGE_CHANNELS")) return message.channel.send({ embeds: [embed1] })

        if (!args[0]) {

            const embed = new MessageEmbed()
                .setColor(color)
                .setThumbnail(gif)
                .setDescription('De slowmode is uitgezet, doe !slowmode 1s (tijd naar keuze) om de slowmode weer aan te zetten')
                .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                .setFooter({ text: `${footer}` })
                .setTimestamp()
            message.channel.setRateLimitPerUser(0);
            return message.channel.send({ embeds: [embed] })
        }

        const raw = args[0];
        const milliseconds = ms(raw)

        const embed3 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Stuur een valide tijd, doe het zo: \`${prefix}slowmode 10m\`. Dit kun je ook met uren doen zoals: \`${prefix}slowmode 1h\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (isNaN(milliseconds)) return message.reply({ embeds: [embed3] })

        const embed4 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 De minimale slowmode is **1 seconde**`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (milliseconds < 1000) return message.reply({ embeds: [embed4] })

        const embed6 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Het maximum voor de slowmode is **6 uur**`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (milliseconds > 21600000) return message.reply({ embeds: [embed6] })

        message.channel.setRateLimitPerUser(milliseconds / 1000);

        const embed5 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`De slowmode is veranderd naar **${ms(milliseconds, {
                long: true,
            })}**`)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        message.channel.send({ embeds: [embed5] })
    }
};

// © Bot created by Sides Hosting & Dev