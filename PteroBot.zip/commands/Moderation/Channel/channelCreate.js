const { MessageEmbed, Message } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;


module.exports = {
    name: "create",
    description: "creeërt een kanaal",
    aliases: ['c'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`BAN_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const channelName = args.join(" ");
        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`🚫 Stuur het kanaalnaam: \`${prefix}create channelnaam\``)
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!channelName) return message.channel.send({ embeds: [embed2] })

        message.guild.channels.create(channelName)
            .then(ch => {
                const embed2 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`Druk ${ch} om naar het kanaal te gaan`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                    return message.channel.send({ embeds: [embed2] })
            });
    }
}

// © Bot created by Sides Hosting & Dev