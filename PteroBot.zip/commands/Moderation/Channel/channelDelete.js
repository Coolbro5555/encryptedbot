const { MessageEmbed, Message, User } = require('discord.js')
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: "delete",
    description: "delete een kanaal",
    aliases: ['del'],
 
    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`BAN_MEMBERS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send({ embeds: [embed1] })

        const channelTarget = message.mentions.channels.first() || message.channel;

        channelTarget.delete()
            .then(ch => {
                const embed2 = new MessageEmbed()
                    .setColor(color)
                    .setThumbnail(gif)
                    .setDescription(`${message.author.tag}, je hebt ${ch} gedelete in ${message.guild.name}`)
                    .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
                    .setFooter({ text: `${footer}` })
                    .setTimestamp()
                return message.author.send({ embeds: [embed2] })
            });
    }
};

// © Bot created by Sides Hosting & Dev