const { MessageEmbed, Message } = require('discord.js')
const ms = require('ms');
const gif = require('../../../utils.json').gif
const color = require('../../../utils.json').color
const footer = require('../../../utils.json').footer
const prefix = process.env.BOT_PREFIX;

module.exports = {
    name: "lock",
    description: "lock een kanaal",
    aliases: ['lo'],

    run: async (client, message, args) => {

        const embed1 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Je hebt geen permissie om dit command te gebruiken! Je hebt \`MANAGE_CHANNELS\` nodig")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        if (!message.member.permissions.has("MANAGE_CHANNELS")) return message.channel.send({ embeds: [embed1] })

        const channel = message.mentions.channels.first() || message.channel;

        channel.permissionOverwrites.edit(
            message.guild.roles.cache.find((x) => x.name === "@everyone"),
            {
                SEND_MESSAGES: false
            }
        );

        const embed2 = new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription(`${message.channel.name} is succesvol geclosed!`)
            .addFields(
                {
                    name: 'Moderator', value: `${message.member}`, inline: true
                },
                {
                    name: 'Kanaal', value: `${message.channel}`, inline: true
                }
            )
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()
        message.channel.send({embeds: [embed2]})
    }
};

// © Bot created by Sides Hosting & Dev