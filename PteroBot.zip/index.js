const { Client, Collection, Message, MessageEmbed } = require("discord.js");

const client = new Client({
    intents: 32767,
});
module.exports = client;

// Global Variables
client.commands = new Collection();
client.slashCommands = new Collection();
const prefix = process.env.BOT_PREFIX;
const token = process.env.DISCORD_TOKEN;

// Initializing the project
require("./Handler")(client);

client.login(token);