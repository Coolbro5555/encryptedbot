const client = require('../index')

client.on('interactionCreate', async (interaction) => {

    if (interaction.isButton()) {

        let interactionCategory = interaction.customId.toString().split("_");

        switch (interactionCategory[0]) {
            case "suggestion":
                await interaction.deferUpdate()
                if (!interaction.member.permissions.has("ADMINISTRATOR")) return;

                switch (interactionCategory[1]) {

                    case "accept":

                        embed = interaction.message.embeds[0].setColor("#00ff00");
                        await interaction.message.edit({
                            embeds: [embed],
                        });

                        break
                    case "deny":

                        embed = interaction.message.embeds[0].setColor("#ff0000");
                        await interaction.message.edit({
                            embeds: [embed],
                        });


                        break;

                }

                break;
        }

    }
})

// © Bot created by Sides Hosting & Dev