const client = require("../index");
const config = require("../config.json");
const { MessageEmbed } = require("discord.js");
const prefix = config.prefix;
const token = config.token;
const warndb = require("../models/warndb");
const badwordschannel = require('../utils.json').badwordschannel


client.on("messageCreate", async (message) => {

    if(!message.guild) return;
    if(message.author.bot) return;
    if(message.channel.type == 'DM') return;
    if(message.member.permissions.has('MANAGE_MESSAGES')) return;

    const arr1 = message.content.toLowerCase().split(" ");
    const arr2 = ['kk', 'kkr', 'kanker', 'neger', 'nigger', 'nigga'];
    const arr3 = message.content;

    const found = arr1.some((r) => arr2.indexOf(r) >= 0);

    if (found) {
        message.delete();
        const embed = new MessageEmbed()
            .setTitle("🚫 **Schelden is niet toegestaan**")
            .setColor("RED");
        message.channel.send({ embeds: [embed] });
    } else {
        return;
    }

    const reason = "Schelden";
    const user = message.member;
    const moderator = client.user.id;

    warndb.findOne(
        {
            guild: message.guild.id,
            user: user.user.id,
        },
        async (err, data) => {
            if (err) throw err;
            if (!data) {
                data = new warndb({
                    guild: message.guild.id,
                    user: user.user.id,
                    content: [
                        {
                            moderator: moderator,
                            reason: reason,
                        },
                    ],
                });
            } else {
                const object = {
                    moderator: moderator,
                    reason: reason,
                };
                data.content.push(object);
            }
            data.save();

            if (data.content.length === 3) {
                const time = 86400000;

                const role = message.guild.roles.cache.find(
                    (role) => role.name.toLowerCase() === "muted"
                );

                if (!role) {
                    try {
                        message.channel.send(
                            "Muted role is not found, attempting to create muted role."
                        );

                        let muterole = await message.guild.roles.create({
                            data: {
                                name: "muted",
                                permissions: [],
                            },
                        });
                        message.guild.channels.cache
                            .filter((c) => c.type === "text")
                            .forEach(async (channel, id) => {
                                await channel.createOverwrite(muterole, {
                                    SEND_MESSAGES: false,
                                    ADD_REACTIONS: false,
                                });
                            });
                        const embed4 = new MessageEmbed()
                            .setColor("RED")
                            .setDescription("✅ Muterole is aagemaakt");
                        message.channel.send({ embeds: [embed4] });
                    } catch (error) {
                        console.log(error);
                    }
                }
                let role2 = message.guild.roles.cache.find(
                    (r) => r.name.toLowerCase() === "muted"
                );

                const embed5 = new MessageEmbed()
                    .setColor("RED")
                    .setDescription("🚫 Member is al gemute!");
                if (user.roles.cache.has(role2))
                    return message.channel.send({ embeds: [embed5] });

                await user.roles.add(role2);

                const embedjee = new MessageEmbed()

                    .setAuthor({
                        name:
                            "WAARSCHUWING",
                        iconURL: user.displayAvatarURL({ dynamic: true, size: 512 })
                    })
                    .setDescription(`Warned ${user} for **${reason}**`)
                    .setColor("RED")
                    .addField("Aantal warns: ", `${data.content.length}`)
                    .addField(
                        "Belangrijk: ",
                        `${user} is nu gemute voor 24h, hierna volgt nog een mute!`
                    )
                    .setTimestamp()
                    .setFooter({ text: `Gewaarschuwd door ${message.author.tag}` });

                message.channel.send({ embeds: [embedjee] });

                setTimeout(async () => {
                    await user.roles.remove(role2);
                    const embed6 = new MessageEmbed()
                        .setColor("GREEN")
                        .setDescription(`✅ ${user.displayName} is ge-unmute!`);
                    message.channel.send({ embeds: [embed6] });
                }, time);
            } else if (data.content.length === 4) {
                const timee = 604800000;

                const rolee = message.guild.roles.cache.find(
                    (role) => role.name.toLowerCase() === "muted"
                );

                if (!rolee) {
                    try {
                        message.channel.send(
                            "Muted role is not found, attempting to create muted role."
                        );

                        let muterolee = await message.guild.roles.create({
                            data: {
                                name: "muted",
                                permissions: [],
                            },
                        });
                        message.guild.channels.cache
                            .filter((c) => c.type === "text")
                            .forEach(async (channel, id) => {
                                await channel.createOverwrite(muterolee, {
                                    SEND_MESSAGES: false,
                                    ADD_REACTIONS: false,
                                });
                            });
                        const embed4 = new MessageEmbed()
                            .setColor("RED")
                            .setDescription("✅ Muterole is aagemaakt");
                        message.channel.send({ embeds: [embed4] });
                    } catch (error) {
                        console.log(error);
                    }
                }
                let rolee2 = message.guild.roles.cache.find(
                    (r) => r.name.toLowerCase() === "muted"
                );

                const embed5 = new MessageEmbed()
                    .setColor("RED")
                    .setDescription("🚫 Member is al gemute!");
                if (user.roles.cache.has(rolee2))
                    return message.channel.send({ embeds: [embed5] });

                await user.roles.add(rolee2);

                const embedjee = new MessageEmbed()

                    .setAuthor({
                        name:
                            "WAARSCHUWING",
                        iconURL: user.displayAvatarURL({ dynamic: true, size: 512 })
                    })
                    .setDescription(`Warned ${user} for **${reason}**`)
                    .setColor("RED")
                    .addField("Aantal warns: ", `${data.content.length}`)
                    .addField(
                        "Belangrijk: ",
                        `${user} is nu gemute voor 1 week, hierna volgt een ban!`
                    )
                    .setTimestamp()
                    .setFooter({ text: `Gewaarschuwd door ${message.author.tag}` });

                message.channel.send({ embeds: [embedjee] });

                setTimeout(async () => {
                    await user.roles.remove(role2);
                    const embed6 = new MessageEmbed()
                        .setColor("GREEN")
                        .setDescription(`✅ ${user.displayName} is ge-unmute!`);
                    message.channel.send({ embeds: [embed6] });
                }, timee);
            } else if (data.content.length === 5) {

                if (user.permissions.has('KICK_MEMBERS')) return;

                if (user) {
                    const reden = "Verbannen door teveel warns";

                    await user
                        .ban({
                            reason: reden,
                        })
                        .then(() => {
                            const banEmbed = new MessageEmbed()

                                .setColor("#34e628")

                                .setAuthor({
                                    name:
                                        "BAN",
                                    iconURL: user.displayAvatarURL({ dynamic: true, size: 512 })
                                })
                                .setDescription(`${user}` + " is gebanned wegens teveel warns!")
                                .addField("Gebruiker:", `${user}`, true)
                                .addField("\u200b", "\u200b", true)
                                .addField("Verbannen door: ", `${message.author.tag}`, true)
                                .setTimestamp()

                            message.channel.send({ embeds: [banEmbed] });
                        });
                } else {
                    const embed2 = new MessageEmbed()
                        .setColor("RED")
                        .setDescription("🚫 Geen gebruiker gevonden!");
                    message.channel.send({ embeds: [embed2] });
                }
            } else {
                const embed12 = new MessageEmbed()

                    .setAuthor({
                        name:
                            "WAARSCHUWING",
                        iconURL: user.displayAvatarURL({ dynamic: true, size: 512 })
                    })
                    .setDescription(`Warned ${user} for **${reason}**`)
                    .setColor("RED")
                    .addField("Aantal warns: ", `${data.content.length}`)
                    .setTimestamp()
                    .setFooter({ text: `Gewaarschuwd door ${message.author.tag}` });

                message.channel.send({ embeds: [embed12] }).then((message) => {

                    const kanaal = message.guild.channels.cache.get(badwordschannel)
                    if(!kanaal) return;

                    const logEmbed = new MessageEmbed()
                        .setTitle('SWEARWORDLOG')
                        .setDescription(`${user} (${message.author.id}) heeft gescholden met: **${arr3}**`)
                        .setTimestamp()
                        .setFooter({ text: `${message.guild.name} - Logs` })
                    kanaal.send({ embeds: [logEmbed] })
                })
            }
        }
    );
});

// © Bot created by Sides Hosting & Dev