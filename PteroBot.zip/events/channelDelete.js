const client = require('../index')
const { MessageEmbed, Collection, Message } = require('discord.js')
const gif = require('../utils.json').gif
const color = require('../utils.json').color
const footer = require('../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const welkomchannel = require('../utils.json').welkomchannel
const welkomrole = require('../utils.json').welkomrole
const ticketpanelid2 = require('../models/ticketpanelSchema')

client.on('channelDelete', async (channel) => {

    //check of het id van het kanaal gelijk staat aan die die gestored is
    const ticketpanelid1 = await ticketpanelid2.findOne({guild: channel.guild.id})
    if(ticketpanelid1 == null) return;
    const ticketpanelid3 = ticketpanelid1.ticketpanelid
    if(channel.id !== ticketpanelid3) return;

    ticketpanelid2.findOne({
        guild: channel.guild.id
    }, async(err, data) => {
        if(data) {

            await ticketpanelid2.findOneAndDelete({
                guild: channel.guild.id,
            })

        }
        
    })

})

// © Bot created by Sides Hosting & Dev