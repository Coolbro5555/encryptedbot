const client = require("../index");
const config = require('../config.json')
const prefix = config.prefix
const token = config.token
const { MessageEmbed, Collection } = require('discord.js');
const { commands } = require("../index");
const cooldowns = new Map()
const cooldownss = new Map()

client.on("messageCreate", async (message) => {


    if (
        message.author.bot ||
        !message.guild ||
        !message.content.toLowerCase().startsWith(prefix)
    )
        return;

    const [cmd, ...args] = message.content
        .slice(prefix.length)
        .trim()
        .split(/ +/g);

    const command = client.commands.get(cmd.toLowerCase()) || client.commands.find(c => c.aliases?.includes(cmd.toLowerCase()));
    if (!command) return;

    // Cooldown voor 1 persoon
    if (!cooldowns.has(command.name)) {
        cooldowns.set(command.name, new Collection());
    }

    var currentTime = Date.now();
    var timeStamps = cooldowns.get(command.name);
    var cooldownTime = command.cooldown * 1000;

    if (timeStamps.has(message.author.id)) {
        var experationTime = timeStamps.get(message.author.id) + cooldownTime;

        if (currentTime < experationTime) {
            var timeLeft = (experationTime - currentTime) / 1000;

            const embed = new MessageEmbed()
                .setTitle(`❌ | Error`)
                .setDescription(`Wacht nog **${timeLeft.toFixed(1)}** seconden om **${prefix}${command.name}** uit te voeren!`)

            return message.reply({ embeds: [embed] });
        } else {
            timeStamps.delete(message.author.id);
        }
    }

    timeStamps.set(message.author.id, currentTime);

    // cooldown voor hele guild
    if (!cooldownss.has(command.name)) {
        cooldownss.set(command.name, new Collection());
    }

    var currentTimee = Date.now();
    var timeStampss = cooldownss.get(command.name);
    var cooldownTimee = command.guildCooldown * 1000;

    if (timeStampss.has(message.guild.id)) {
        var experationTimee = timeStampss.get(message.guild.id) + cooldownTimee;

        if (currentTimee < experationTimee) {
            var timeLeftt = (experationTimee - currentTimee) / 1000;

            const embed = new MessageEmbed()
                .setTitle(`❌ | Error`)
                .setDescription(`Wacht nog **${timeLeftt.toFixed(1)}** seconden om **${prefix}${command.name}** uit te voeren!`)

            return message.reply({ embeds: [embed] });
        } else {
            timeStampss.delete(message.guild.id);
        }
    }

    timeStampss.set(message.guild.id, currentTimee);

    await command.run(client, message, args);


});


// © Bot created by Sides Hosting & Dev