const client = require('../index')
const { MessageEmbed, MessageButton, MessageActionRow, MessageSelectMenu } = require('discord.js');
const { Collection } = require('mongoose');
const { channels, user } = require('../index');
const fs = require('fs');
const gif = require('../utils.json').gif
const color = require('../utils.json').color
const footer = require('../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const ticketstaffrole = require('../utils.json').ticketstaffrole
const ticket1 = require('../utils.json').ticket1
const ticket2 = require('../utils.json').ticket2
const ticket3 = require('../utils.json').ticket3
const ticket4 = require('../utils.json').ticket4
const ticket5 = require('../utils.json').ticket5
const ticket6 = require('../utils.json').ticket6

client.on('interactionCreate', async (interaction) => {

  if (interaction.isSelectMenu()) {

    if (interaction.values[0] === 'ticket1') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket1}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket1} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`🎫 ・ Nieuw Ticket!`)
        .setThumbnail(gif)
        .addFields(
          { name: `\u200b`, value: `${interaction.user.username}, hier is jouw ticket. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket1}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] === 'ticket2') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket2}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket2} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
        READ_MESSAGE_HISTORY: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`Ticket: ${interaction.user.tag}`)
        .addFields(
          { name: `\u200b`, value: `Welkom in het ticket, ${interaction.user.username}. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket2}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] === 'ticket3') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket3}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket3} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
        READ_MESSAGE_HISTORY: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`Ticket: ${interaction.user.tag}`)
        .addFields(
          { name: `\u200b`, value: `Welkom in het ticket, ${interaction.user.username}. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket3}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] === 'ticket4') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket4}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket4} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
        READ_MESSAGE_HISTORY: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`Ticket: ${interaction.user.tag}`)
        .addFields(
          { name: `\u200b`, value: `Welkom in het ticket, ${interaction.user.username}. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket4}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] === 'ticket5') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket5}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket5} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
        READ_MESSAGE_HISTORY: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`Ticket: ${interaction.user.tag}`)
        .addFields(
          { name: `\u200b`, value: `Welkom in het ticket, ${interaction.user.username}. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket5}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] === 'ticket6') {

      interaction.deferUpdate()
      const channel = await interaction.guild.channels.create(`${ticket6}・${interaction.user.tag}`, {
        topic: interaction.user.id
      });

      const parent1 = interaction.guild.channels.cache.find(channel => channel.type == "GUILD_CATEGORY" && channel.name == `${ticket6} - Ticket`)
      channel.setParent(parent1)

      channel.permissionOverwrites.edit(
        interaction.guild.roles.cache.find((x) => x.name === "@everyone"),
        {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false,
        }
      );

      channel.permissionOverwrites.edit(interaction.user.id, {
        VIEW_CHANNEL: true,
        SEND_MESSAGES: true,
        ATTACH_FILES: true,
        CONNECT: true,
        ADD_REACTIONS: true,
        READ_MESSAGE_HISTORY: true,
      });

      let embed = new MessageEmbed()
        .setTitle(`Ticket: ${interaction.user.tag}`)
        .addFields(
          { name: `\u200b`, value: `Welkom in het ticket, ${interaction.user.username}. Stel alvast jouw vraag, zodat het staffteam jou zo snel mogelijk tewoord kan staan.` },
          { name: `Ticketspecifies:`, value: `👨‍💻 ・ ${prefix}rename\n🔒 ・ Close\n✋ ・ Claim\n\n📃 ・ Auteur: ${interaction.user.tag}\n❓ ・ Onderwerp: ${ticket6}` },
        )
        .setFooter({ text: `${interaction.guild.name} - Tickets`, iconURL: `${gif}` })
        .setTimestamp()
        .setColor(color)

      let nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions(
            {
              emoji: '✋',
              label: 'Claim',
              description: 'Claim ticket',
              value: "ticketoption1"
            },
            {
              emoji: '🔒',
              label: 'Close',
              description: 'Close ticket',
              value: "ticketoption2"
            }
          )
      );

      await channel.send({ content: `<@!${interaction.user.id}> & <@&${ticketstaffrole}>`, embeds: [embed], components: [nv] })
      const embed2 = new MessageEmbed()
        .setDescription(`✅ ${channel} is gecreeërt!`)
        .setColor(color)
      interaction.followUp({ embeds: [embed2], ephemeral: true })

    }

    if (interaction.values[0] == 'Reset') {
      const embed = new MessageEmbed()
        .setColor(color)
        .setThumbnail(gif)
        .setDescription(`${interaction.user.tag} jouw keuze is gereset!`)
        .setAuthor({ name: `${interaction.guild.name}`, iconURL: `${gif}` })
        .setFooter({ text: `${footer}` })
        .setTimestamp()
      interaction.reply({ embeds: [embed], ephemeral: true })
    }

    if (interaction.values[0] == 'ticketoption1') {

      if (!interaction.member.permissions.has("MANAGE_MESSAGES")) return interaction.reply({ content: 'Jij kan dit niet doen! Alleen staff kan een ticket claimen', ephemeral: true })
      interaction.deferUpdate()
      const user = interaction.channel.topic
      const us = interaction.guild.members.cache.get(user)

      const embed = new MessageEmbed()
        .setColor(color)
        .setThumbnail(gif)
        .setDescription(`${interaction.user.tag} helpt jou bij deze ticket!`)
        .setAuthor({ name: `${interaction.guild.name}`, iconURL: `${gif}` })
        .addFields(
          {
            name: "Moderator:", value: `${interaction.user.tag}`, inline: true
          },
          {
            name: "Channel:", value: `${interaction.channel.name}`, inline: true
          },
          {
            name: "Ticket van:", value: `${us}`, inline: true
          },
        )
        .setFooter({ text: `${footer}` })
        .setTimestamp()
      interaction.channel.send({ embeds: [embed] })
    }

    if (interaction.values[0] == 'ticketoption2') {

      interaction.deferUpdate()

      const user = interaction.channel.topic
      const us = interaction.guild.members.cache.get(user)
      interaction.channel.permissionOverwrites.edit(user,
        {
          SEND_MESSAGES: false
        }
      )

      const embedd = new MessageEmbed()
        .setColor(color)
        .setThumbnail(gif)
        .setDescription(`Deze ticket wordt geclosed! Kies een van de onderstaande acties: \n\n・ \`Heropenen\`\n・ \`Verwijderen\``)
        .setAuthor({ name: `${interaction.guild.name}`, iconURL: `${gif}` })
        .addFields(
          {
            name: "Geclosed door:", value: `${interaction.user.tag}`, inline: true
          },
          {
            name: "Channel:", value: `${interaction.channel.name}`, inline: true
          },
          {
            name: "Ticket van:", value: `${us}`, inline: true
          },
        )
        .setFooter({ text: `${footer}` })
        .setTimestamp()

      const nv = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId('ja')
          .setPlaceholder('❌ | Nog niets geselecteerd')
          .addOptions({
            emoji: '✅',
            label: `Heropenen`,
            description: `Heropen het ticket`,
            value: "Heropenen"
          },
            {
              emoji: '❌',
              label: `Delete`,
              description: `Delete het ticket`,
              value: "Delete"
            },
          )
      )
      interaction.channel.send({ embeds: [embedd], components: [nv] })

    }

    if (interaction.values[0] === 'Heropenen') {

      if (!interaction.member.permissions.has("MANAGE_MESSAGES")) return interaction.reply({ content: 'Jij kan dit niet doen! Vraag aan de staff of ze de ticket willen heropenen.', ephemeral: true })
      interaction.deferUpdate()

      const user = interaction.channel.topic
      const us = interaction.guild.members.cache.get(user)
      interaction.channel.permissionOverwrites.edit(user,
        {
          SEND_MESSAGES: true
        }
      )

      const embed2 = new MessageEmbed()
        .setColor(color)
        .setThumbnail(gif)
        .setDescription(`Het ticket is succesvol weer ge-opend!`)
        .addFields(
          {
            name: 'Moderator', value: `${interaction.member}`, inline: true
          },
          {
            name: 'Kanaal', value: `${interaction.channel}`, inline: true
          }
        )
        .setAuthor({ name: `${interaction.guild.name}`, iconURL: `${gif}` })
        .setFooter({ text: `${footer}` })
        .setTimestamp()
      interaction.channel.send({ embeds: [embed2] })
    }

    if (interaction.values[0] === 'Delete') {

      const { createTranscript } = require('discord-html-transcripts')

      if (!interaction.member.permissions.has("MANAGE_MESSAGES")) return interaction.reply({ content: 'Jij kan dit niet doen! Vraag aan de staff of ze de ticket willen sluiten.', ephemeral: true })
      interaction.deferUpdate()

      const user = interaction.channel.topic
      const us = interaction.guild.members.cache.get(user)

      const transcriptFile = await createTranscript(interaction.channel, {
        limit: -1,
        fileName: `${interaction.channel.name}.html`,
        returnBuffer: false
      });

      var spul = new MessageEmbed()
        .setAuthor({ name: `${interaction.guild.name} - Ticket Close`, iconURL: `${gif}` })
        .setThumbnail(gif)
        .addFields(
          {
            name: "Moderator:", value: `${interaction.user.tag}`, inline: true
          },
          {
            name: "Channelnaam:", value: `${interaction.channel.name}`, inline: true
          },
          {
            name: "User:", value: `${us}`, inline: true
          },
          {
            name: "Server:", value: `${interaction.guild.name}`, inline: true
          },
        )
        .setFooter({ text: 'Ticket is compleet!' })
        .setTimestamp()
        .setColor(color)

      const ticketlogchannel = require('../utils.json').ticketlogkanaal
      if(!ticketlogchannel) return;
      const channell = interaction.guild.channels.cache.get(ticketlogchannel)
      channell.send({ embeds: [spul], files: [transcriptFile] })

      var embedTicket = new MessageEmbed()
        .setTitle('Ticket: ' + `${interaction.channel.name}`)
        .setDescription('Ticket wordt geclosed in **5 seconden**')
        .setFooter({ text: 'Ticket is compleet!' })
        .setTimestamp()
        .setColor(color)

      interaction.channel.send({ embeds: [embedTicket] })
      setTimeout(() => {
        interaction.channel.delete();
      }, 5000);


    }

  }

})

// © Bot created by Sides Hosting & Dev