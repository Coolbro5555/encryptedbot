const { Message, MessageEmbed } = require('discord.js');
const { user } = require('../index');
const client = require('../index');

client.on('messageCreate', async (message) => {

    if(!message.guild) return;
    if(message.author.bot) return;
    if(message.channel.type == 'DM') return;
    if(message.member.permissions.has('MANAGE_MESSAGES')) return;
    const user = message.member

    async function deleteMessage() {
        message.delete();

        const time = 86400000
        const role = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'muted')

        if (!role) {

            try {

                message.channel.send('Muted role is not found, attempting to create muted role.')

                let muterole = await message.guild.roles.create({
                    data: {
                        name: 'muted',
                        permissions: []
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                    })
                });
                message.channel.send('Muted role has sucessfully been created.')
            } catch (error) {
                console.log(error)
            }
        };
        let role2 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')

        if (user.roles.cache.has(role2.id)) return message.channel.send(`${user} has already been muted.`)

        await user.roles.add(role2)

        const embedjeee = new MessageEmbed()

            .setAuthor({ name: "WAARSCHUWING", iconURL: user.displayAvatarURL({ dynamic: true, size: 512 }) })
            .setDescription(`${user} is 24 uur gemute wegens het plaatsen van een discord invite!`)
            .setColor(color)
            .setTimestamp()

        message.channel.send({ embeds: [embedjeee] })

        setTimeout(async () => {
            await user.roles.remove(role2)
            const embed1 = new MessageEmbed()
                .setColor(color)
                .setDescription(`✅ ${user} is geunmute`)
            message.channel.send({ embeds: [embed1] })
        }, (time))
    }

    const links = ['discord.gg/', 'Discord.gg/', 'discord.com/invite/', 'Discord.com/invite/', 'https://'];

    for (const link of links) {

        if (!message.content.includes(link)) return;

        const code = message.content.split(link)[1].split(" ")[0];
        const isGuildInvite = message.guild.invites.cache.has(code);

        if (!isGuildInvite) {
            try {
                const vanity = await message.guild.fetchVanityData();
                if (code !== vanity?.code) return deleteMessage()
            } catch (err) {
                deleteMessage();
            }
        }
    }
});

// © Bot created by Sides Hosting & Dev