const client = require("../index");
const config = require('../config.json')
const prefix = config.prefix
const token = config.token
const { MessageEmbed } = require('discord.js');
const { guilds } = require("../index");
const guildConfigs = require('../models/guildConfig')
const users = require('../models/userConfig')
const gif = require('../utils.json').gif
const color = require('../utils.json').color
const footer = require('../utils.json').footer
const levelupchannel = require('../utils.json').levelupchannel


client.on("messageCreate", async (message) => {

    if(message.channel.type == 'DM') return;
    if (!message.guild) return;
    if(message.author.bot) return;
    
    const user = message.mentions.members.first() || message.author;
    const data = await guildConfigs.findOne({ id: message.guild.id }) || {};

    if (data.xp || data?.ignoreXP?.includes(message.channel.id) || message.author.bot) return;

    const userData = await users.findOne({ user: user.id, guild: message.guild.id }) || await users.create({ user: user.id, guild: message.guild.id, xp: 0, level: 0 });

    if (userData.lastXP + (data.xpTimeout || 1000) > Date.now()) return;

    var xp = Math.floor(Math.random() * 5) + 1, reqXP = 100;
    userData.xp += xp;

    for (let i = 1; i <= userData.level; i++)reqXP += 5 * (i ^ 2) + (50 * i) + 100;
    const data1 = await users.findOne({ user: user.id, guild: message.guild.id }) || {};
    const nodigXP = reqXP - data1.xp;

    if (userData.xp >= reqXP) {
        userData.level += 1;

        const embed1 = new MessageEmbed()
            .setAuthor({ name: `🎉| ${user.username || user.displayName} rang omhoog!`, iconURL: `${user.displayAvatarURL()}` })
            .setDescription(`Gefelicicteerd ${user.username || user.displayName}! Je bent gevorderd naar level **${userData.level}**!`)
            .setColor(color)

        const kanaal = message.guild.channels.cache.get(levelupchannel)
        if(!kanaal) return message.reply({embeds: [new MessageEmbed()
            .setColor(color)
            .setThumbnail(gif)
            .setDescription("🚫 Het id van het kanaal waarin de levelup klopt niet. Contacteer de creator om dit op te lossen!")
            .setAuthor({ name: `${message.guild.name}`, iconURL: `${gif}` })
            .setFooter({ text: `${footer}` })
            .setTimestamp()]})
        kanaal.send({ embeds: [embed1] })
    }

    await users.findOneAndUpdate({ user: user.id, guild: message.guild.id }, {
        xp: userData.xp,
        level: userData.level,
        lastXP: Date.now()
    })

    const embed = new MessageEmbed()
        .addFields(
            { name: "XP", value: `${data1.xp || 0}`, inline: true },
            { name: "Level", value: `${data1.level || 0}`, inline: true },
            { name: "ReqXP", value: `${reqXP || 0}`, inline: true },
            { name: 'Spelernaam', value: `${user.displayName || user.username}`, inline: true },
            { name: 'Spelerid', value: `${user.id}`, inline: true },
            { name: 'Nodig voor volgend level', value: `${nodigXP}` },
        )
        .setColor(color)
        .setAuthor({ name: `${user.username || user.displayName} zijn rank kaart!`, iconURL: `${user.displayAvatarURL()}` })
    if (message.content.startsWith(`${prefix}rank`)) return message.channel.send({ embeds: [embed] })


});
