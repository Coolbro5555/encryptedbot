const client = require('../index')
const { MessageEmbed, Collection, Message } = require('discord.js')
const gif = require('../utils.json').gif
const color = require('../utils.json').color
const footer = require('../utils.json').footer
const prefix = process.env.BOT_PREFIX;
const welkomchannel = require('../utils.json').welkomchannel
const welkomrole = require('../utils.json').welkomrole

client.on('guildMemberAdd', async (member) => {

    var role = member.guild.roles.cache.get(welkomrole);

    if (!role) return;

    member.roles.add(role);

    var channel = member.guild.channels.cache.get(welkomchannel);

    if (!channel) return;

    const embed = new MessageEmbed()
        
        .setThumbnail(gif)
        .setAuthor({ name: `New Member!`, iconURL: `${gif}` })
        .addField(`\u200b`, `Welkom ${member}! Mooi dat je de **${member.guild.name}** discord bent gejoint, lees de regels goed en heb een goede tijd!`)
        .addFields(
            {
                name: `👤 Members:`, value: `Wij hebben nu **${member.guild.memberCount}** leden!`, inline: true
            },
        )
        .setFooter({ text: `${member.guild.memberCount} members`, iconURL: member.user.displayAvatarURL({ dynamic: true, size: 512 }) })
        .setTimestamp()
        .setColor(color)

    channel.send({ embeds: [embed] })
})

// © Bot created by Sides Hosting & Dev