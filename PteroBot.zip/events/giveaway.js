const client = require('../index')
const { GiveawaysManager } = require("discord-giveaways");

client.giveawaysManager = new GiveawaysManager(client, {
  storage: "./storage/giveaways.json",
  default: {
    botsCanWin: false,
    embedColor: "#8a0308",
    reaction: "🎉",
    lastChance: {
      enabled: true,
      content: `🛑 **Laatste kans om nog mee te doen** 🛑`,
      threshold: 5000,
      embedColor: '#FF0000'
    }
  }
});

// © Bot created by Sides Hosting & Dev