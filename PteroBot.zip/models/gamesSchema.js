const { Schema, model } = require('mongoose');

const games = new Schema({

    user: String,
    guild: String,
    coins: Number,

})

module.exports = model("Games", games);