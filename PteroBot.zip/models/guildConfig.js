const { Schema, model } = require('mongoose');

const guildStats = new Schema({

    id: String,
    ignoreXP: [String],
    xp: Boolean,
    xpTimeout: Number,
})

module.exports = model("guildStats", guildStats);