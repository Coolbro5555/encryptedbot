const mongoose = require('mongoose')

const ticketpanelid = new mongoose.Schema({
    guild: String,
    ticketpanelid: String,
})

module.exports = mongoose.model("ticketpanelid", ticketpanelid);