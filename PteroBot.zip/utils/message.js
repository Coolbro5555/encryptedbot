const config = require('../config.json');
module.exports = {
  giveaway:
    (config.everyoneMention ? "@everyone\n\n" : "") +
    "🎉 **GIVEAWAY** 🎉",
  giveawayEnded:
    (config.everyoneMention ? "@everyone\n\n" : "") +
    "🎉 **GIVEAWAY GEÏNDIGD** 🎉",
  drawing:  `Eindigd: **{timestamp}**`,
  inviteToParticipate: `React with 🎉 to participate!`,
  winMessage: "Gefeliciteerd, {winners}! Je hebt **{this.prize}** gewonnen!",
  embedFooter: "Giveaways",
  noWinner: "Giveaway gestopt, niet genoeg deelnemers",
  hostedBy: "Gehost door: {this.hostedBy}",
  winners: "winner(s)",
  endedAt: "Geïndigd op"
}